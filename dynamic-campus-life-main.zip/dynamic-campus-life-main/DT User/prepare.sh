#!/usr/bin/env bash
# DT User — One-shot Android APK builder for the User app.
# Run from inside the "DT User" folder:  ./prepare.sh
set -e

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
WORK="$HERE/work"
OUT="$HERE/build"

APP_ID="user.khsdowntownlobby"
APP_NAME="Downtown Lobby"

echo "▶ DT User builder"
echo "  source : $ROOT"
echo "  work   : $WORK"
echo "  output : $OUT"

# 1. Fresh working copy of the project (excluding heavy/ephemeral folders)
rm -rf "$WORK"
mkdir -p "$WORK" "$OUT"
echo "▶ Copying source…"
rsync -a \
  --exclude node_modules \
  --exclude .git \
  --exclude dist \
  --exclude android \
  --exclude ios \
  --exclude "DT Admin" \
  --exclude "DT User" \
  --exclude .workspace \
  "$ROOT/" "$WORK/"

# 2. Inject user-only configuration
echo "▶ Injecting user config…"
cp "$HERE/capacitor.config.json" "$WORK/capacitor.config.json"
cp "$HERE/env.user" "$WORK/.env.production"
export VITE_APP_ROLE=user

# 2b. Prepare assets for icon generation
echo "▶ Preparing assets for icon generation…"
mkdir -p "$WORK/assets"
SOURCE_IMAGE="$ROOT/public/logo.png"
if [ -f "$SOURCE_IMAGE" ]; then
  cp "$SOURCE_IMAGE" "$WORK/assets/icon-only.png"
  cp "$SOURCE_IMAGE" "$WORK/assets/icon-foreground.png"
  cp "$SOURCE_IMAGE" "$WORK/assets/icon-background.png"
  cp "$SOURCE_IMAGE" "$WORK/assets/splash.png"
else
  echo "⚠️ Source image $SOURCE_IMAGE not found!"
fi

# 3. Install deps & build web assets
cd "$WORK"
echo "▶ Installing dependencies…"
npm install --no-audit --no-fund

echo "▶ Building web bundle…"
npm run build

# 4. Add Android platform if missing, sync, and assemble debug APK
if [ ! -d "$WORK/android" ]; then
  echo "▶ Adding Android platform…"
  npx cap add android
fi

echo "▶ Syncing Capacitor…"
npx cap sync android

echo "▶ Generating Assets…"
npx capacitor-assets generate --android || true

# 5. Patch package id in the native project
sed -i.bak -E "s|applicationId \".*\"|applicationId \"$APP_ID\"|g" \
  "$WORK/android/app/build.gradle" || true

echo "▶ Assembling debug APK…"
cd "$WORK/android"
chmod +x ./gradlew
./gradlew assembleDebug

APK="$WORK/android/app/build/outputs/apk/debug/app-debug.apk"
FINAL_NAME="KHS Downtown user.apk"
if [ -f "$APK" ]; then
  cp "$APK" "$OUT/$FINAL_NAME"
  echo ""
  echo "✅ Done: $OUT/$FINAL_NAME"
  echo "   Package: $APP_ID"
  echo "   Install on phone with:  adb install -r \"$OUT/$FINAL_NAME\""
else
  echo "❌ APK not found. Check Gradle output above."
  exit 1
fi
