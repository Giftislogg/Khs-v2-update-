# DT User — Android APK builder

This folder builds a **standalone Android APK of the User app** (no admin routes loaded by default; admin is still reachable via /admin/login if needed).

- **App name:** Downtown Lobby
- **Package id:** `user.khsdowntownlobby`

## What's inside

- `prepare.sh` — one-shot script that copies the project, configures it for the user build, and produces a debug APK
- `capacitor.config.json` — Capacitor config used for the user build
- `env.user` — env file injected into the build (`VITE_APP_ROLE=user`)

## Requirements (run on your own machine)

- Node 18+ and npm
- Java JDK 17
- Android SDK + `ANDROID_HOME`

## Build

```bash
cd "DT User"
chmod +x prepare.sh
./prepare.sh
```

Output: `DT User/build/KHS Downtown user.apk`
