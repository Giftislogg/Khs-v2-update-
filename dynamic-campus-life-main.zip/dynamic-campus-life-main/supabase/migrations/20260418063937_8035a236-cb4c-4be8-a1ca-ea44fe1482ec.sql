-- PDFs table for Studies section
CREATE TABLE public.pdfs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  pdf_url TEXT NOT NULL,
  thumbnail_url TEXT,
  category TEXT DEFAULT 'general',
  recommended BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.pdfs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read pdfs" ON public.pdfs FOR SELECT USING (true);
CREATE POLICY "Admins can manage pdfs" ON public.pdfs FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_pdfs_updated_at BEFORE UPDATE ON public.pdfs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Add video URL support (in addition to uploaded files) - already has video_url, but allow YouTube/Vimeo embeds
-- Add a video_type column to distinguish
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS video_type TEXT NOT NULL DEFAULT 'file';

-- Post likes (anonymous count)
CREATE TABLE public.post_likes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(post_id, client_id)
);

ALTER TABLE public.post_likes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read post_likes" ON public.post_likes FOR SELECT USING (true);
CREATE POLICY "Anyone can like posts" ON public.post_likes FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can unlike own" ON public.post_likes FOR DELETE USING (true);

CREATE INDEX idx_post_likes_post_id ON public.post_likes(post_id);

-- Post comments (anonymous, name + content)
CREATE TABLE public.post_comments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  author_name TEXT NOT NULL DEFAULT 'Student',
  content TEXT NOT NULL,
  client_id TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.post_comments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read comments" ON public.post_comments FOR SELECT USING (true);
CREATE POLICY "Anyone can comment" ON public.post_comments FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can delete comments" ON public.post_comments FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE INDEX idx_post_comments_post_id ON public.post_comments(post_id);