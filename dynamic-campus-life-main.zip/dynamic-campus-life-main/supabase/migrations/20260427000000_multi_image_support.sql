-- Add image_urls column to posts and events for multi-image support
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS image_urls text[] DEFAULT '{}';
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS image_urls text[] DEFAULT '{}';
