-- Add grade column to timetables for class-specific schedules
ALTER TABLE public.timetables ADD COLUMN IF NOT EXISTS grade text;
CREATE INDEX IF NOT EXISTS idx_timetables_grade ON public.timetables(grade);

-- Device tokens for native push notifications (FCM/APNs)
CREATE TABLE IF NOT EXISTS public.device_tokens (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token text NOT NULL UNIQUE,
  platform text NOT NULL DEFAULT 'android',
  client_id text,
  topics text[] NOT NULL DEFAULT ARRAY['announcements','posts','events','timetables']::text[],
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  last_seen_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.device_tokens ENABLE ROW LEVEL SECURITY;

-- Anyone (the app on a device) can register/refresh their own token
CREATE POLICY "Anyone can register a device token"
ON public.device_tokens FOR INSERT
TO public
WITH CHECK (true);

CREATE POLICY "Anyone can update own device token"
ON public.device_tokens FOR UPDATE
TO public
USING (true)
WITH CHECK (true);

CREATE POLICY "Admins can read device tokens"
ON public.device_tokens FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete device tokens"
ON public.device_tokens FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_device_tokens_updated_at
BEFORE UPDATE ON public.device_tokens
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();