ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS image_urls text[] DEFAULT '{}'::text[];
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS image_urls text[] DEFAULT '{}'::text[];