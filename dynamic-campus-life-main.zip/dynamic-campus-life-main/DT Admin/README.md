# DT Admin — Android APK builder

This folder builds a **standalone Android APK of the Admin Panel only**.

- **App name:** Downtown Lobby Admin
- **Package id:** `admin.khsdowntownlobby`
- **Entry:** Goes straight to the admin login / dashboard (no user app routes)

## What's inside

- `prepare.sh` — one-shot script that copies the project, configures it for the admin build, and produces `app-debug.apk`
- `capacitor.config.json` — Capacitor config used for the admin build
- `env.admin` — env file injected into the build (`VITE_APP_ROLE=admin`)

## Requirements (run on your own machine, not in Lovable)

- Node 18+ and npm
- Java JDK 17
- Android SDK + `ANDROID_HOME` env var set
  (Android Studio installs both — easiest path)

## How to build

```bash
cd "DT Admin"
chmod +x prepare.sh
./prepare.sh
```

When it finishes you'll find:

```
DT Admin/build/app-debug.apk
```

Copy that APK to your phone and install it (allow "Install unknown apps").

## Re-building after code changes

Just run `./prepare.sh` again — it will re-copy the latest source from the
parent project, rebuild the web assets, and re-assemble the APK.
