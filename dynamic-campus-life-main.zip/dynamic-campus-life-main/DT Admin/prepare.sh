#!/usr/bin/env bash
# DT Admin — One-shot Android APK builder for the Admin Panel only.
# Run from inside the "DT Admin" folder:  ./prepare.sh
set -e

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
WORK="$HERE/work"
OUT="$HERE/build"

APP_ID="admin.khsdowntownlobby"
APP_NAME="Downtown Lobby Admin"

echo "▶ DT Admin builder"
echo "  source : $ROOT"
echo "  work   : $WORK"
echo "  output : $OUT"

# 1. Fresh working copy of the project (excluding heavy/ephemeral folders)
rm -rf "$WORK"
mkdir -p "$WORK" "$OUT"
echo "▶ Copying source…"
rsync -a \
  --exclude node_modules \
  --exclude .git \
  --exclude dist \
  --exclude android \
  --exclude ios \
  --exclude "DT Admin" \
  --exclude .workspace \
  "$ROOT/" "$WORK/"

# 2. Inject admin-only configuration
echo "▶ Injecting admin config…"
cp "$HERE/capacitor.config.json" "$WORK/capacitor.config.json"
cp "$HERE/env.admin" "$WORK/.env.production"
# Also expose VITE_APP_ROLE at build time for safety
export VITE_APP_ROLE=admin

# 2b. Prepare assets for icon generation
echo "▶ Preparing assets for icon generation…"
mkdir -p "$WORK/assets"
# Use 'supabase/images (3).jpeg' as requested
SOURCE_IMAGE="$ROOT/supabase/images (3).jpeg"
if [ -f "$SOURCE_IMAGE" ]; then
  cp "$SOURCE_IMAGE" "$WORK/assets/icon-only.png"
  cp "$SOURCE_IMAGE" "$WORK/assets/icon-foreground.png"
  cp "$SOURCE_IMAGE" "$WORK/assets/icon-background.png"
  cp "$SOURCE_IMAGE" "$WORK/assets/splash.png"
else
  echo "⚠️ Source image $SOURCE_IMAGE not found!"
fi

# 3. Install deps & build web assets
cd "$WORK"
echo "▶ Installing dependencies…"
npm install --no-audit --no-fund

echo "▶ Building web bundle…"
npm run build

# 4. Add Android platform if missing, sync, and assemble debug APK
if [ ! -d "$WORK/android" ]; then
  echo "▶ Adding Android platform…"
  npx cap add android
fi

echo "▶ Syncing Capacitor…"
npx cap sync android

echo "▶ Generating Assets…"
npx capacitor-assets generate --android

# 5. Patch package id in the native project (Capacitor sets it on add, but we
#    re-assert it in case the platform existed already).
sed -i.bak -E "s|applicationId \".*\"|applicationId \"$APP_ID\"|g" \
  "$WORK/android/app/build.gradle" || true

echo "▶ Assembling debug APK…"
cd "$WORK/android"
chmod +x ./gradlew
./gradlew assembleDebug

APK="$WORK/android/app/build/outputs/apk/debug/app-debug.apk"
FINAL_NAME="KHS Downtown admin.apk"
if [ -f "$APK" ]; then
  cp "$APK" "$OUT/$FINAL_NAME"
  echo ""
  echo "✅ Done: $OUT/$FINAL_NAME"
  echo "   Package: $APP_ID"
  echo "   Install on phone with:  adb install -r \"$OUT/$FINAL_NAME\""
else
  echo "❌ APK not found. Check Gradle output above."
  exit 1
fi
