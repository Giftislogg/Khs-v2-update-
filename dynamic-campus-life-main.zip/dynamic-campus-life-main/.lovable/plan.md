# Khanyisa High School App — Phased Build Plan

This is a large scope (10+ new modules, dark mode, sidebar nav, notification engine, term tracking). To ship it well without breaking the current working app (Posts, Events, Studies, Timetable, Admin), I'll do it in phases. Please confirm or adjust.

## Phase 1 — Foundation (ship first)
- **Sidebar drawer navigation** (hamburger on mobile) with all 11 routes listed. Keep the existing bottom nav for the 4 most-used (Home, Posts, Events, Studies) so muscle memory survives; sidebar holds the rest.
- **Dark mode + light mode** toggle (saved per device). Audit existing screens to use semantic tokens.
- **SA School Term Progress Bar** on Home:
  - Hardcoded 2026 SA public school calendar (Gauteng dates — confirm province).
  - Auto-detect current term, % progress, days/weeks remaining, closing date.
  - "School Closed" / "Holiday Break" states.
  - Tap → **Term Insights** page (calendar, exam countdowns, announcements, motivational message). Charts come in Phase 3.

## Phase 2 — Discipline Module
- **Gate Lock Countdown** to 07:25 (green/orange/red states) on Home + dedicated page.
- **Uniform & House Colour Tracker**: weekly calendar showing standard vs. Wednesday house colours/tracksuit, with night-before push notification.
- **Digital Absentee Note** upload (parent submits photo/PDF of note → stored in `absence_notes` table, admin reviews).
- *Deferred:* Actual gate-scan tardy pass requires hardware integration — I'll build a manual "I arrived late" self-report that logs to student profile instead. Confirm OK.

## Phase 3 — Academics & Interventions
- **Academic Progress** page: parent/student enters or admin posts term marks; Level 1 scores auto-flag.
- **Afternoon Classes**: admin posts schedule; auto-invite (push + in-app) to flagged Level 1 students.
- **Term Insights charts**: attendance %, performance trends, homework stats (requires data entry surfaces — will add admin tools).

## Phase 4 — Community & Profile
- **Sports & Clubs** page (admin-managed fixtures, results, club list).
- **Assemblies & Liturgy** page (weekly schedule, scripture/theme of week).
- **Parent Portal** (link parent account to student, view marks/attendance/notes).
- **Student Profile** (grade, house, photo, incident log).
- **Settings** (notification prefs, theme, account).

## Phase 5 — Notification Engine
Unified system covering: late alerts, afternoon class reminders, sports, uniform, assembly, emergency, academic warnings, parent–teacher messages. Builds on existing `notifications.ts` and device tokens.

---

## Research notes I need from you (can't reliably web-scrape a specific school)
I don't want to invent Khanyisa-specific facts. Please confirm or paste:
1. **Province** (for SA term dates) — Gauteng? KZN?
2. **House names & colours** (e.g. Red/Blue/Green/Gold houses?).
3. **Assembly schedule** (which days, denomination/liturgy style).
4. **Sports offered** & main season fixtures.
5. **Grade range** — currently 8A–9D. Add 10/11/12?
6. **Gate-close time** — confirmed 07:25?
7. **Official school motto/colours** beyond "Let Your Light Shine" + navy/gold (already in app).

## Technical notes
- New tables needed: `absence_notes`, `student_marks`, `afternoon_class_invites`, `sports_fixtures`, `clubs`, `assemblies`, `student_profiles`, `parent_links`, `incidents`, `house_calendar`.
- All RLS-protected; admin writes, public/authed reads where appropriate.
- Reuses existing Supabase, notifications, and APK build pipeline (DT User / DT Admin) — no changes needed there.
- Dark mode requires auditing ~15 files to swap hardcoded colors for tokens.

## What I need from you to start
1. **Approve the phasing** (or tell me to do it all at once — will be much slower and riskier).
2. **Answer the 7 research questions above** (or say "use sensible defaults and I'll correct later").
3. **Confirm Phase 1 scope is what you want first.**

Once you reply, I'll start Phase 1 immediately.