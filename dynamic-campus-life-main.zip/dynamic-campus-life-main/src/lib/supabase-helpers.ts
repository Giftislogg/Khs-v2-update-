import { supabase } from "@/integrations/supabase/client";

export const uploadMedia = async (file: File, folder: string) => {
  const ext = file.name.split('.').pop();
  const fileName = `${folder}/${Date.now()}.${ext}`;
  const { data, error } = await supabase.storage.from('media').upload(fileName, file);
  if (error) throw error;
  const { data: urlData } = supabase.storage.from('media').getPublicUrl(data.path);
  return urlData.publicUrl;
};

export const uploadMultipleMedia = async (files: FileList | File[], folder: string) => {
  const fileArray = Array.from(files);
  const uploadPromises = fileArray.map(file => uploadMedia(file, folder));
  return Promise.all(uploadPromises);
};

export const deleteMedia = async (url: string) => {
  try {
    const path = url.split('/media/')[1];
    if (path) {
      await supabase.storage.from('media').remove([path]);
    }
  } catch (e) {
    console.error('Failed to delete media:', e);
  }
};

export const APP_VERSION = '0.2';

// Anonymous client identifier for likes/comments
export const getClientId = (): string => {
  let id = localStorage.getItem('dl_client_id');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('dl_client_id', id);
  }
  return id;
};

// Convert YouTube/Vimeo URL to embed URL
export const toEmbedUrl = (url: string): string => {
  // YouTube
  const ytMatch = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|v\/)|youtu\.be\/)([^&?\/\s]{11})/);
  if (ytMatch) return `https://www.youtube.com/embed/${ytMatch[1]}?autoplay=1&rel=0`;
  // Vimeo
  const vmMatch = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (vmMatch) return `https://player.vimeo.com/video/${vmMatch[1]}?autoplay=1`;
  return url;
};
