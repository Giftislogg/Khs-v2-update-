// South African public school term calendar (inland provinces: Gauteng/Free State/etc.)
// Source: Department of Basic Education annual gazette.
// NOTE: Update yearly. Defaults provided for 2025, 2026, 2027.

export type TermDef = { term: 1 | 2 | 3 | 4; start: string; end: string };

const CALENDARS: Record<number, TermDef[]> = {
  2025: [
    { term: 1, start: '2025-01-15', end: '2025-03-28' },
    { term: 2, start: '2025-04-08', end: '2025-06-27' },
    { term: 3, start: '2025-07-22', end: '2025-10-03' },
    { term: 4, start: '2025-10-13', end: '2025-12-10' },
  ],
  2026: [
    { term: 1, start: '2026-01-14', end: '2026-03-27' },
    { term: 2, start: '2026-04-07', end: '2026-06-26' },
    { term: 3, start: '2026-07-21', end: '2026-10-02' },
    { term: 4, start: '2026-10-12', end: '2026-12-09' },
  ],
  2027: [
    { term: 1, start: '2027-01-13', end: '2027-03-26' },
    { term: 2, start: '2027-04-06', end: '2027-06-25' },
    { term: 3, start: '2027-07-20', end: '2027-10-01' },
    { term: 4, start: '2027-10-11', end: '2027-12-08' },
  ],
};

export type TermStatus = {
  mode: 'in_term' | 'holiday' | 'closed';
  term: TermDef | null;
  nextTerm: TermDef | null;
  daysRemaining: number;
  weeksRemaining: number;
  totalDays: number;
  daysElapsed: number;
  percent: number;
  closingDate: string | null;
  message: string;
};

const dayDiff = (a: Date, b: Date) =>
  Math.round((b.getTime() - a.getTime()) / 86400000);

const fmt = (d: string) =>
  new Date(d).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' });

export function getTermStatus(now: Date = new Date()): TermStatus {
  const year = now.getFullYear();
  const cal = CALENDARS[year] ?? CALENDARS[2026];
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  // Find current term
  const current = cal.find((t) => {
    const s = new Date(t.start);
    const e = new Date(t.end);
    return today >= s && today <= e;
  });

  if (current) {
    const start = new Date(current.start);
    const end = new Date(current.end);
    const totalDays = dayDiff(start, end) + 1;
    const daysElapsed = Math.max(0, Math.min(totalDays, dayDiff(start, today) + 1));
    const daysRemaining = Math.max(0, dayDiff(today, end));
    const percent = Math.round((daysElapsed / totalDays) * 100);
    return {
      mode: 'in_term',
      term: current,
      nextTerm: cal.find((t) => new Date(t.start) > end) ?? null,
      daysRemaining,
      weeksRemaining: Math.ceil(daysRemaining / 7),
      totalDays,
      daysElapsed,
      percent,
      closingDate: current.end,
      message: `Term ${current.term} in progress`,
    };
  }

  // Find next upcoming term
  const next = cal.find((t) => new Date(t.start) > today);
  if (next) {
    const daysUntil = dayDiff(today, new Date(next.start));
    const isEndOfYear = false;
    return {
      mode: 'holiday',
      term: null,
      nextTerm: next,
      daysRemaining: daysUntil,
      weeksRemaining: Math.ceil(daysUntil / 7),
      totalDays: 0,
      daysElapsed: 0,
      percent: 0,
      closingDate: next.start,
      message: `Holiday Break — Term ${next.term} starts ${fmt(next.start)}`,
    };
  }

  // No more terms this year
  return {
    mode: 'closed',
    term: null,
    nextTerm: null,
    daysRemaining: 0,
    weeksRemaining: 0,
    totalDays: 0,
    daysElapsed: 0,
    percent: 100,
    closingDate: null,
    message: 'School Closed — see you next year!',
  };
}

export function getAllTerms(year?: number): TermDef[] {
  const y = year ?? new Date().getFullYear();
  return CALENDARS[y] ?? CALENDARS[2026];
}
