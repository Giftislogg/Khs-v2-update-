/**
 * Native push + in-app notifications for Capacitor Android/iOS builds.
 *
 * - On native: registers FCM/APNs token, stores it in `device_tokens`, and
 *   shows local notifications when realtime delivers a new row.
 * - On web: silently no-ops (browser push isn't part of this build).
 *
 * Call `initNotifications()` once at app start. Safe to call multiple times.
 */
import { supabase } from '@/integrations/supabase/client';
import { getClientId } from '@/lib/supabase-helpers';

let initialized = false;

const isNative = (): boolean => {
  // Capacitor injects this global on native runtimes.
  const w = typeof window !== 'undefined' ? (window as any) : null;
  return !!(w && w.Capacitor && typeof w.Capacitor.isNativePlatform === 'function' && w.Capacitor.isNativePlatform());
};

export async function initNotifications(): Promise<void> {
  if (initialized) return;
  initialized = true;

  // Realtime → local notification (works on native + web for in-app)
  setupRealtimeBridge();

  if (!isNative()) return;

  // Small delay to ensure native plugins are fully ready and avoid race conditions on startup
  setTimeout(async () => {
    try {
      const { PushNotifications } = await import('@capacitor/push-notifications');
      const { LocalNotifications } = await import('@capacitor/local-notifications');

      // Ask permission (push + local)
      let perm;
      try {
        perm = await PushNotifications.checkPermissions();
        if (perm.receive === 'prompt' || perm.receive === 'prompt-with-rationale') {
          perm = await PushNotifications.requestPermissions();
        }
      } catch (e) {
        console.warn('[notifications] push permissions failed', e);
      }

      try {
        await LocalNotifications.requestPermissions();
      } catch (e) {
        console.warn('[notifications] local permissions failed', e);
      }

      if (!perm || perm.receive !== 'granted') {
        console.log('[notifications] permissions not granted', perm);
        return;
      }

      // Cleanup existing listeners to prevent leaks/double-handling on hot-reload or rapid restarts
      try {
        await PushNotifications.removeAllListeners();
      } catch {}

      // Register and store token
      PushNotifications.addListener('registration', async (token) => {
        try {
          const platform = (window as any)?.Capacitor?.getPlatform?.() || 'android';
          await supabase
            .from('device_tokens' as any)
            .upsert(
              {
                token: token.value,
                platform,
                client_id: getClientId(),
                last_seen_at: new Date().toISOString(),
              },
              { onConflict: 'token' }
            );
        } catch (e) {
          console.warn('[notifications] failed to save token', e);
        }
      });

      PushNotifications.addListener('registrationError', (err) => {
        console.warn('[notifications] registration error', err);
      });

      // Foreground push → show as local notification so it's visible
      PushNotifications.addListener('pushNotificationReceived', async (n) => {
        try {
          await LocalNotifications.schedule({
            notifications: [
              {
                id: Date.now() % 2147483647,
                title: n.title || 'Downtown Lobby',
                body: n.body || '',
              },
            ],
          });
        } catch {}
      });

      await PushNotifications.register();
    } catch (e) {
      console.warn('[notifications] init failed', e);
    }
  }, 1000);
}

/**
 * Listen to Supabase realtime inserts on key tables and surface a local
 * notification on native devices. This works without FCM as a baseline.
 */
function setupRealtimeBridge() {
  const topics: { table: string; label: string; titleField: string }[] = [
    { table: 'announcements', label: 'New announcement', titleField: 'title' },
    { table: 'posts', label: 'New post', titleField: 'title' },
    { table: 'events', label: 'New event', titleField: 'title' },
    { table: 'timetables', label: 'New timetable', titleField: 'title' },
  ];

  const channel = supabase.channel('dl-notifications');
  for (const t of topics) {
    channel.on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: t.table },
      async (payload) => {
        const title = (payload.new as any)?.[t.titleField] || t.label;
        await showLocal(t.label, title);
      }
    );
  }
  channel.subscribe();
}

async function showLocal(title: string, body: string) {
  if (!isNative()) return;
  try {
    const { LocalNotifications } = await import('@capacitor/local-notifications');
    await LocalNotifications.schedule({
      notifications: [
        {
          id: Date.now() % 2147483647,
          title,
          body,
        },
      ],
    });
  } catch {}
}
