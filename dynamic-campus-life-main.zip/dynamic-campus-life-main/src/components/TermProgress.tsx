import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, ChevronRight, GraduationCap } from 'lucide-react';
import { getTermStatus } from '@/lib/saTerms';

const TermProgress = () => {
  const navigate = useNavigate();
  const [status, setStatus] = useState(() => getTermStatus());
  const [animatedPct, setAnimatedPct] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setStatus(getTermStatus()), 60_000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setAnimatedPct(status.percent), 200);
    return () => clearTimeout(t);
  }, [status.percent]);

  const inTerm = status.mode === 'in_term';

  return (
    <button
      onClick={() => navigate('/term-insights')}
      className="w-full text-left mx-5 mb-6 block"
      style={{ width: 'calc(100% - 2.5rem)' }}
    >
      <div className="relative overflow-hidden rounded-3xl p-5 navy-gradient card-shadow-lg active:scale-[0.99] transition-transform">
        <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-gold/20 blur-3xl pointer-events-none" />
        <div className="relative flex items-start justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl gold-gradient flex items-center justify-center shadow-md">
              <GraduationCap className="w-5 h-5 text-primary" strokeWidth={2.4} />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-widest font-bold text-gold-light">
                SA School Term
              </p>
              <p className="text-white font-extrabold text-base leading-tight">
                {inTerm ? `Term ${status.term?.term}` : status.mode === 'holiday' ? 'Holiday Break' : 'School Closed'}
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-white/60 mt-1" />
        </div>

        {inTerm ? (
          <>
            <div className="relative h-3 rounded-full bg-white/10 overflow-hidden mb-3">
              <div
                className="h-full gold-gradient rounded-full transition-all duration-[1500ms] ease-out shadow-[0_0_12px_rgba(245,201,72,0.6)]"
                style={{ width: `${animatedPct}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-white/80 font-semibold">
              <span className="text-gold-light text-sm font-extrabold">{status.percent}%</span>
              <span>
                {status.daysRemaining} days · {status.weeksRemaining} wk left
              </span>
            </div>
            {status.closingDate && (
              <div className="flex items-center gap-1.5 mt-3 text-[10.5px] text-white/60">
                <Calendar className="w-3 h-3" />
                <span>
                  Closes{' '}
                  {new Date(status.closingDate).toLocaleDateString('en-ZA', {
                    weekday: 'short',
                    day: 'numeric',
                    month: 'short',
                  })}
                </span>
              </div>
            )}
          </>
        ) : (
          <div className="text-white/80 text-xs">{status.message}</div>
        )}
      </div>
    </button>
  );
};

export default TermProgress;
