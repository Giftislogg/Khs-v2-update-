import { useEffect, useState } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import Autoplay from 'embla-carousel-autoplay';
import { supabase } from '@/integrations/supabase/client';
import { Megaphone, Calendar, Newspaper } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

type Slide = {
  id: string;
  kind: 'announcement' | 'event' | 'post';
  title: string;
  subtitle?: string | null;
  image?: string | null;
  date?: string | null;
  path: string;
};

const kindMeta = {
  announcement: { icon: Megaphone, label: 'Announcement', tone: 'navy-gradient', text: 'text-white' },
  event: { icon: Calendar, label: 'Event', tone: 'gold-gradient', text: 'text-primary' },
  post: { icon: Newspaper, label: 'News', tone: 'navy-gradient', text: 'text-white' },
} as const;

const HeroCarousel = () => {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [selected, setSelected] = useState(0);
  const navigate = useNavigate();
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: 'center', duration: 28 }, [
    Autoplay({ delay: 4500, stopOnInteraction: false }),
  ]);

  useEffect(() => {
    const load = async () => {
      const [a, e, p] = await Promise.all([
        supabase.from('announcements').select('*').order('created_at', { ascending: false }).limit(2),
        supabase.from('events').select('*').order('event_date', { ascending: true }).limit(3),
        supabase.from('posts').select('*').order('created_at', { ascending: false }).limit(3),
      ]);
      const mixed: Slide[] = [];

      const localImages = [
        '/supabase/2.jpg',
        '/supabase/6.jpg',
        '/supabase/images.jpeg',
        '/supabase/unnamed.jpg',
      ];

      (a.data || []).forEach((x) =>
        mixed.push({
          id: `a-${x.id}`,
          kind: 'announcement',
          title: x.title,
          subtitle: x.content,
          image: localImages[0],
          path: '/',
        })
      );

      // Expand multi-image events into one slide per image
      (e.data || []).forEach((x) => {
        const imgs = (x.image_urls && x.image_urls.length > 0 ? x.image_urls : [x.image_url || localImages[1]]) as string[];
        imgs.forEach((img, i) => {
          mixed.push({
            id: `e-${x.id}-${i}`,
            kind: 'event',
            title: x.title,
            subtitle: x.description,
            image: img,
            date: x.event_date,
            path: '/events',
          });
        });
      });

      // Expand multi-image posts into one slide per image
      (p.data || []).forEach((x) => {
        const imgs = (x.image_urls && x.image_urls.length > 0 ? x.image_urls : [x.image_url || localImages[2]]) as string[];
        imgs.forEach((img, i) => {
          mixed.push({
            id: `p-${x.id}-${i}`,
            kind: 'post',
            title: x.title,
            subtitle: x.content,
            image: img,
            path: '/posts',
          });
        });
      });

      if (mixed.length === 0) {
        mixed.push({
          id: 'welcome',
          kind: 'announcement',
          title: 'Welcome to Downtown Lobby',
          subtitle: 'Let your light shine at Khanyisa High School',
          image: localImages[3],
          path: '/',
        });
      }

      // Light shuffle while keeping reasonable variety, cap at 8
      setSlides(mixed.slice(0, 8));
      setLoaded(true);
    };
    load();
  }, []);

  useEffect(() => {
    if (!emblaApi) return;
    const onSelect = () => setSelected(emblaApi.selectedScrollSnap());
    emblaApi.on('select', onSelect);
    onSelect();
  }, [emblaApi, slides.length]);

  // While loading, render a neutral placeholder (no flash of "no posts" style)
  if (!loaded) {
    return (
      <div className="px-5 mb-6 animate-fade-in">
        <div className="rounded-3xl h-44 bg-gradient-to-br from-muted/60 to-muted animate-pulse" />
      </div>
    );
  }

  if (slides.length === 0) {
    return (
      <div className="px-5 mb-6">
        <div className="gold-radial rounded-3xl p-6 h-44 flex flex-col justify-center card-shadow-lg">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Welcome</p>
          <h3 className="text-lg font-bold mt-1">Stay tuned for updates</h3>
          <p className="text-muted-foreground text-sm mt-1">Announcements & events will appear here.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-6 animate-fade-in">
      <div className="overflow-hidden" ref={emblaRef}>
        <div className="flex">
          {slides.map((s) => {
            const meta = kindMeta[s.kind];
            const Icon = meta.icon;
            return (
              <div key={s.id} className="flex-[0_0_100%] min-w-0 px-5">
                <button
                  onClick={() => navigate(s.path)}
                  className="w-full text-left rounded-3xl overflow-hidden card-shadow-lg relative h-44 group active:scale-[0.98] transition-transform"
                >
                  {s.image ? (
                    <>
                      <img src={s.image} alt={s.title} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                    </>
                  ) : (
                    <div className={`absolute inset-0 ${meta.tone}`} />
                  )}
                  <div className="relative h-full flex flex-col justify-end p-6 text-white">
                    <div className="flex items-center gap-2 mb-3">
                      <div className={`w-8 h-8 rounded-xl ${meta.tone} flex items-center justify-center shadow-lg`}>
                        <Icon className={`w-4 h-4 ${meta.text}`} />
                      </div>
                      <span className="text-[10px] uppercase tracking-[0.2em] font-black">{meta.label}</span>
                    </div>
                    <h3 className="font-black text-xl leading-tight mb-1 drop-shadow-md">{s.title}</h3>
                    {s.subtitle && <p className="text-white/80 text-xs font-medium line-clamp-2 max-w-[90%]">{s.subtitle}</p>}
                  </div>
                </button>
              </div>
            );
          })}
        </div>
      </div>
      <div className="flex justify-center gap-1.5 mt-3">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => emblaApi?.scrollTo(i)}
            className={`h-1.5 rounded-full transition-all ${
              selected === i ? 'w-6 bg-gold' : 'w-1.5 bg-muted'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroCarousel;
