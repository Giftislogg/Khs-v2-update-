import { Play, X, Maximize2 } from 'lucide-react';
import { useState } from 'react';
import { toEmbedUrl } from '@/lib/supabase-helpers';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';

interface Props {
  url: string;
  type: 'file' | 'url';
  thumbnail?: string | null;
  title: string;
}

const VideoPlayer = ({ url, type, thumbnail, title }: Props) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <button
          className="relative w-full aspect-video bg-foreground/5 group overflow-hidden cursor-pointer"
        >
          {thumbnail ? (
            <img src={thumbnail} alt={title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/80 to-foreground/60" />
          )}
          <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/40 transition-colors">
            <div className="w-12 h-12 rounded-full gold-gradient flex items-center justify-center shadow-lg group-active:scale-95 transition-transform">
              <Play className="w-5 h-5 text-primary fill-current ml-0.5" />
            </div>
          </div>
          <div className="absolute bottom-2 right-2 p-1.5 rounded-lg bg-black/40 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity">
            <Maximize2 className="w-3 h-3 text-white" />
          </div>
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-[95vw] w-full p-0 overflow-hidden bg-black border-none gap-0 sm:max-w-[800px]">
        <div className="relative w-full aspect-video bg-black flex items-center justify-center">
          {type === 'file' ? (
            <video
              src={url}
              controls
              autoPlay
              playsInline
              className="w-full h-full max-h-[85vh]"
            />
          ) : (
            <iframe
              src={toEmbedUrl(url)}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              title={title}
            />
          )}
          <button
            onClick={() => setIsOpen(false)}
            className="absolute -top-12 right-0 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur flex items-center justify-center text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        {title && (
          <div className="p-4 bg-black/90 border-t border-white/10">
            <h3 className="text-white font-medium line-clamp-1">{title}</h3>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default VideoPlayer;
