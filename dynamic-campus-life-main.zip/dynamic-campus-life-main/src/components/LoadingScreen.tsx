import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

const LoadingScreen = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [shouldRender, setShouldRender] = useState(false);

  useEffect(() => {
    const hasShown = sessionStorage.getItem("dl_splash_shown");
    if (hasShown) return;

    setIsVisible(true);
    setShouldRender(true);
    sessionStorage.setItem("dl_splash_shown", "true");

    // Keep splash for 2 seconds
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 2000);

    // Remove from DOM after animation finishes
    const removeTimer = setTimeout(() => {
      setShouldRender(false);
    }, 2500);

    return () => {
      clearTimeout(timer);
      clearTimeout(removeTimer);
    };
  }, []);

  if (!shouldRender) return null;

  return (
    <div
      className={cn(
        "fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-background transition-opacity duration-500",
        !isVisible && "opacity-0 pointer-events-none"
      )}
    >
      <div className="relative">
        <div className="w-24 h-24 rounded-3xl bg-card card-shadow-lg flex items-center justify-center animate-splash-logo overflow-hidden">
          <img src="/logo.png" alt="Logo" className="w-16 h-16 object-contain" />
        </div>
        <div className="absolute -inset-4 rounded-[40px] border-2 border-gold/20 animate-ping opacity-20" />
      </div>

      <div className="mt-8 text-center animate-fade-in delay-300">
        <h1 className="text-xl font-bold tracking-tight text-foreground">Downtown Lobby</h1>
        <p className="text-sm text-muted-foreground mt-1">Let your light shine</p>
      </div>

      <div className="absolute bottom-12 flex gap-1">
        <div className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce [animation-delay:-0.3s]" />
        <div className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce [animation-delay:-0.15s]" />
        <div className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce" />
      </div>
    </div>
  );
};

export default LoadingScreen;
