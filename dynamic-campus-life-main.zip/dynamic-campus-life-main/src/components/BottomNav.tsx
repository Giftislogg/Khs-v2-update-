import { Home, Star, BookOpen } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';

const tabs = [
  { path: '/', icon: Home, label: 'Home' },
  { path: '/entertainment', icon: Star, label: 'Highlights', center: true },
  { path: '/studies', icon: BookOpen, label: 'Studies' },
];

const BottomNav = () => {
  const location = useLocation();
  const navigate = useNavigate();

  if (location.pathname.startsWith('/admin')) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 pb-[env(safe-area-inset-bottom)] pointer-events-none">
      <nav className="pointer-events-auto mx-auto max-w-md px-4 pb-3">
        <div className="relative bg-card/85 backdrop-blur-2xl border border-border/50 rounded-[28px] shadow-[0_10px_30px_-8px_rgba(15,23,42,0.18)]">
          <div className="flex items-center justify-around h-16 px-4">
            {tabs.map((tab) => {
              const active = location.pathname === tab.path;
              const Icon = tab.icon;

              if (tab.center) {
                return (
                  <button
                    key={tab.path}
                    onClick={() => navigate(tab.path)}
                    className="relative -mt-8 flex flex-col items-center gap-1 group"
                    aria-label={tab.label}
                  >
                    <div
                      className={`w-14 h-14 rounded-2xl flex items-center justify-center gold-gradient shadow-[0_10px_22px_-6px_rgba(212,175,55,0.55)] ring-4 ring-card transition-all duration-300 ${
                        active ? 'scale-110' : 'scale-100 group-active:scale-95'
                      }`}
                    >
                      <Icon className="w-6 h-6 text-primary" strokeWidth={2.6} />
                    </div>
                    <span
                      className={`text-[10px] font-bold tracking-tight transition-colors ${
                        active ? 'text-primary' : 'text-primary/60'
                      }`}
                    >
                      {tab.label}
                    </span>
                  </button>
                );
              }

              return (
                <button
                  key={tab.path}
                  onClick={() => navigate(tab.path)}
                  className="flex-1 flex flex-col items-center gap-1 py-1 active:scale-95 transition-transform"
                  aria-label={tab.label}
                >
                  <div
                    className={`px-3.5 py-1.5 rounded-2xl transition-all duration-300 ${
                      active ? 'bg-primary/8' : ''
                    }`}
                  >
                    <Icon
                      className={`w-[22px] h-[22px] transition-all duration-300 ${
                        active ? 'text-primary' : 'text-muted-foreground/70'
                      }`}
                      strokeWidth={active ? 2.6 : 2}
                    />
                  </div>
                  <span
                    className={`text-[10.5px] font-bold tracking-tight transition-colors ${
                      active ? 'text-primary' : 'text-muted-foreground/60'
                    }`}
                  >
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default BottomNav;
