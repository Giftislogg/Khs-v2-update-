import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Menu, X, Home, Calendar, Newspaper, BookOpen, Clock, Sparkles,
  ShieldAlert, GraduationCap, Trophy, BookMarked, Bell, User, Settings,
  Moon, Sun, Users,
} from 'lucide-react';
import { useTheme } from '@/lib/theme';

type Item = { path: string; label: string; icon: typeof Home; soon?: boolean };

const items: { group: string; entries: Item[] }[] = [
  {
    group: 'Main',
    entries: [
      { path: '/', label: 'Home', icon: Home },
      { path: '/posts', label: 'News & Posts', icon: Newspaper },
      { path: '/events', label: 'Events', icon: Calendar },
      { path: '/studies', label: 'Studies', icon: BookOpen },
      { path: '/timetable', label: 'Timetable', icon: Clock },
      { path: '/entertainment', label: 'Highlights', icon: Sparkles },
    ],
  },
  {
    group: 'Khanyisa',
    entries: [
      { path: '/term-insights', label: 'Term Insights', icon: GraduationCap },
      { path: '/discipline', label: 'Attendance & Discipline', icon: ShieldAlert, soon: true },
      { path: '/academics', label: 'Academic Progress', icon: BookMarked, soon: true },
      { path: '/afternoon', label: 'Afternoon Classes', icon: Clock, soon: true },
      { path: '/sports', label: 'Sports & Clubs', icon: Trophy, soon: true },
      { path: '/assemblies', label: 'Assemblies & Liturgy', icon: Bell, soon: true },
    ],
  },
  {
    group: 'You',
    entries: [
      { path: '/parent', label: 'Parent Portal', icon: Users, soon: true },
      { path: '/profile', label: 'Student Profile', icon: User, soon: true },
      { path: '/settings', label: 'Settings', icon: Settings, soon: true },
    ],
  },
];

export const DrawerTrigger = ({ onClick }: { onClick: () => void }) => (
  <button
    onClick={onClick}
    aria-label="Open menu"
    className="p-3 rounded-2xl bg-card card-shadow active:scale-95 transition-transform"
  >
    <Menu className="w-5 h-5 text-primary" strokeWidth={2.4} />
  </button>
);

const SideDrawer = ({ open, onClose }: { open: boolean; onClose: () => void }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, toggle } = useTheme();

  const go = (path: string, soon?: boolean) => {
    if (soon) return;
    onClose();
    navigate(path);
  };

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        className={`fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm transition-opacity duration-300 ${
          open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      />
      {/* Panel */}
      <aside
        className={`fixed top-0 left-0 bottom-0 z-[61] w-[84%] max-w-[320px] bg-card text-foreground shadow-2xl flex flex-col transition-transform duration-300 ease-out ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="p-5 pt-7 border-b border-border/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="" className="w-11 h-11 rounded-full object-cover shadow-sm" />
            <div>
              <p className="font-extrabold text-primary leading-tight">Downtown Lobby</p>
              <p className="text-[10px] uppercase tracking-widest text-gold-dark font-semibold">
                Khanyisa High School
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close menu"
            className="p-2 rounded-xl hover:bg-muted active:scale-95 transition"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto py-3 px-3 scrollbar-hide">
          {items.map((sec) => (
            <div key={sec.group} className="mb-4">
              <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground px-3 mb-1.5">
                {sec.group}
              </p>
              {sec.entries.map((it) => {
                const active = location.pathname === it.path;
                const Icon = it.icon;
                return (
                  <button
                    key={it.path}
                    onClick={() => go(it.path, it.soon)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all ${
                      active
                        ? 'bg-primary text-primary-foreground font-bold shadow-sm'
                        : 'text-foreground/80 hover:bg-muted active:scale-[0.98]'
                    } ${it.soon ? 'opacity-50' : ''}`}
                  >
                    <Icon className="w-[18px] h-[18px]" strokeWidth={active ? 2.6 : 2.2} />
                    <span className="text-sm flex-1">{it.label}</span>
                    {it.soon && (
                      <span className="text-[9px] font-bold uppercase tracking-wider text-gold-dark bg-gold/15 px-1.5 py-0.5 rounded">
                        Soon
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Footer: theme toggle */}
        <div className="p-4 border-t border-border/50">
          <button
            onClick={toggle}
            className="w-full flex items-center justify-between gap-3 px-4 py-3 rounded-2xl bg-muted hover:bg-muted/80 active:scale-[0.98] transition"
          >
            <span className="flex items-center gap-2 text-sm font-semibold text-foreground">
              {theme === 'dark' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              {theme === 'dark' ? 'Dark Mode' : 'Light Mode'}
            </span>
            <span
              className={`relative w-10 h-6 rounded-full transition-colors ${
                theme === 'dark' ? 'bg-gold' : 'bg-primary/20'
              }`}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  theme === 'dark' ? 'translate-x-[18px]' : 'translate-x-0.5'
                }`}
              />
            </span>
          </button>
        </div>
      </aside>
    </>
  );
};

export default SideDrawer;
