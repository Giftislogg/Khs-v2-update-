import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { uploadMedia, deleteMedia, uploadMultipleMedia } from '@/lib/supabase-helpers';
import { Plus, Trash2, Edit2, X } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';

// Convert "YYYY-MM-DDTHH:mm" (local) <-> ISO and "" for empty
const toLocalInput = (iso?: string | null) => {
  if (!iso) return '';
  const d = new Date(iso);
  const tz = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - tz).toISOString().slice(0, 16);
};

const AdminPosts = () => {
  const [items, setItems] = useState<Tables<'posts'>[]>([]);
  const [editing, setEditing] = useState<string | null>(null);
  const [form, setForm] = useState({ title: '', content: '', category: 'general', created_at: '' });
  const [files, setFiles] = useState<File[]>([]);
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = () => supabase.from('posts').select('*').order('created_at', { ascending: false }).then(({ data }) => data && setItems(data));
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!form.title.trim() || !form.content.trim()) {
      toast({ title: 'Missing info', description: 'Title and content are required.', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      let currentUrls = [...imageUrls];
      if (files.length > 0) {
        const newUrls = await uploadMultipleMedia(files, 'posts');
        currentUrls = [...currentUrls, ...newUrls];
        setFiles([]);
      }
      const { created_at, ...rest } = form;
      const payload: any = {
        ...rest,
        image_url: currentUrls[0] || null,
        image_urls: currentUrls
      };
      if (created_at) payload.created_at = new Date(created_at).toISOString();
      const { error } = editing
        ? await supabase.from('posts').update(payload).eq('id', editing)
        : await supabase.from('posts').insert(payload);
      if (error) throw error;
      toast({ title: editing ? 'Updated' : 'Created', description: 'Post saved.' });
      setForm({ title: '', content: '', category: 'general', created_at: '' });
      setImageUrls([]);
      setEditing(null);
      load();
    } catch (e: any) {
      toast({ title: 'Could not save', description: e.message || 'Unknown error', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (item: Tables<'posts'>) => {
    if (item.image_urls && item.image_urls.length > 0) {
      await Promise.all(item.image_urls.map(url => deleteMedia(url)));
    } else if (item.image_url) {
      await deleteMedia(item.image_url);
    }
    await supabase.from('posts').delete().eq('id', item.id);
    load();
  };

  const removeImageUrl = (index: number) => {
    setImageUrls(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div>
      <div className="bg-card rounded-2xl p-4 mb-4 space-y-3">
        <h3 className="font-semibold text-sm">{editing ? 'Edit' : 'New'} Post</h3>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Title" className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm" />
        <textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} placeholder="Content" rows={4} className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm" />
        <input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="Category (e.g. notice, sports, academic)" className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm" />
        <div>
          <label className="text-[11px] text-muted-foreground font-medium block mb-1">Publish date (past or future — leave empty for now)</label>
          <input
            type="datetime-local"
            value={form.created_at}
            onChange={(e) => setForm({ ...form, created_at: e.target.value })}
            className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm"
          />
        </div>
        <div className="space-y-2">
          <label className="text-[11px] text-muted-foreground font-medium block">Images</label>
          <div className="flex flex-wrap gap-2 mb-2">
            {imageUrls.map((url, idx) => (
              <div key={idx} className="relative w-16 h-16">
                <img src={url} className="w-full h-full rounded-lg object-cover border border-border" />
                <button
                  onClick={() => removeImageUrl(idx)}
                  className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full p-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={(e) => setFiles(Array.from(e.target.files || []))}
            className="text-sm block w-full"
          />
          {files.length > 0 && <p className="text-[10px] text-muted-foreground">{files.length} new files selected</p>}
        </div>
        <button onClick={save} disabled={saving} className="px-4 py-2 rounded-lg gold-gradient text-sm font-bold text-primary flex items-center gap-1 disabled:opacity-50"><Plus className="w-3 h-3" />{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</button>
      </div>
      <div className="space-y-2">
        {items.map((i) => (
          <div key={i.id} className="bg-card rounded-xl p-3 flex items-center gap-3">
            <div className="flex -space-x-4 overflow-hidden">
              {(i.image_urls && i.image_urls.length > 0 ? i.image_urls : i.image_url ? [i.image_url] : []).slice(0, 3).map((url, idx) => (
                <img key={idx} src={url} className="inline-block h-10 w-10 rounded-lg ring-2 ring-background object-cover" />
              ))}
              {(i.image_urls?.length || 0) > 3 && (
                <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-muted text-[10px] font-medium ring-2 ring-background">
                  +{(i.image_urls?.length || 0) - 3}
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-sm truncate">{i.title}</h4>
              <p className="text-xs text-muted-foreground">{i.category}</p>
            </div>
            <div className="flex gap-1">
              <button onClick={() => {
                setEditing(i.id);
                setForm({ title: i.title, content: i.content, category: i.category || 'general', created_at: toLocalInput(i.created_at) });
                setImageUrls(i.image_urls || (i.image_url ? [i.image_url] : []));
              }} className="p-1.5 rounded-lg hover:bg-muted"><Edit2 className="w-3 h-3" /></button>
              <button onClick={() => remove(i)} className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-3 h-3" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminPosts;
