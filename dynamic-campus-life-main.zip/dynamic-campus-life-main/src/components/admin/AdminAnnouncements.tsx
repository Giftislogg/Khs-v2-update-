import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Trash2, Edit2 } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';

const AdminAnnouncements = () => {
  const [items, setItems] = useState<Tables<'announcements'>[]>([]);
  const [editing, setEditing] = useState<string | null>(null);
  const [form, setForm] = useState({ title: '', content: '', priority: 'normal' });
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = () => supabase.from('announcements').select('*').order('created_at', { ascending: false }).then(({ data }) => data && setItems(data));
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!form.title.trim() || !form.content.trim()) {
      toast({ title: 'Missing info', description: 'Title and content are required.', variant: 'destructive' });
      return;
    }
    setSaving(true);
    const { error } = editing
      ? await supabase.from('announcements').update(form).eq('id', editing)
      : await supabase.from('announcements').insert(form);
    setSaving(false);
    if (error) {
      toast({ title: 'Could not save', description: error.message, variant: 'destructive' });
      return;
    }
    toast({ title: editing ? 'Updated' : 'Created', description: 'Announcement saved.' });
    setForm({ title: '', content: '', priority: 'normal' });
    setEditing(null);
    load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('announcements').delete().eq('id', id);
    if (error) toast({ title: 'Delete failed', description: error.message, variant: 'destructive' });
    else load();
  };

  return (
    <div>
      <div className="bg-card rounded-2xl p-4 mb-4 space-y-3">
        <h3 className="font-semibold text-sm">{editing ? 'Edit' : 'New'} Announcement</h3>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Title" className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm" />
        <textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} placeholder="Content" rows={3} className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm" />
        <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })} className="px-3 py-2 rounded-lg bg-background border border-border text-sm">
          <option value="normal">Normal</option>
          <option value="high">High</option>
          <option value="urgent">Urgent</option>
        </select>
        <div className="flex gap-2">
          <button onClick={save} disabled={saving} className="px-4 py-2 rounded-lg gold-gradient text-sm font-bold text-primary flex items-center gap-1 disabled:opacity-50"><Plus className="w-3 h-3" />{saving ? 'Saving…' : editing ? 'Update' : 'Create'}</button>
          {editing && <button onClick={() => { setEditing(null); setForm({ title: '', content: '', priority: 'normal' }); }} className="px-4 py-2 rounded-lg bg-muted text-sm">Cancel</button>}
        </div>
      </div>
      <div className="space-y-2">
        {items.map((i) => (
          <div key={i.id} className="bg-card rounded-xl p-3 flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h4 className="font-medium text-sm truncate">{i.title}</h4>
                {i.priority === 'urgent' && <span className="text-[10px] bg-destructive/10 text-destructive px-1.5 py-0.5 rounded">Urgent</span>}
              </div>
              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{i.content}</p>
            </div>
            <div className="flex gap-1">
              <button onClick={() => { setEditing(i.id); setForm({ title: i.title, content: i.content, priority: i.priority || 'normal' }); }} className="p-1.5 rounded-lg hover:bg-muted"><Edit2 className="w-3 h-3" /></button>
              <button onClick={() => remove(i.id)} className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-3 h-3" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminAnnouncements;
