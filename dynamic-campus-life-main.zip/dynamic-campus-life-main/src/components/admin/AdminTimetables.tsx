import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { uploadMedia, deleteMedia } from '@/lib/supabase-helpers';
import { Plus, Trash2 } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';

const GRADES = ['8A', '8B', '8C', '8D', '9A', '9B', '9C', '9D'] as const;

const AdminTimetables = () => {
  const [items, setItems] = useState<Tables<'timetables'>[]>([]);
  const [form, setForm] = useState({ title: '', type: 'weekly' as 'weekly' | 'exam', grade: '8A' });
  const [file, setFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = () => supabase.from('timetables').select('*').order('created_at', { ascending: false }).then(({ data }) => data && setItems(data));
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!form.title.trim() || !file) {
      toast({ title: 'Missing info', description: 'Title and an image file are required.', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const imageUrl = await uploadMedia(file, 'timetables');
      const { error } = await supabase.from('timetables').insert({ ...form, image_url: imageUrl } as any);
      if (error) throw error;
      toast({ title: 'Uploaded', description: `Timetable for ${form.grade} saved.` });
      setForm({ title: '', type: 'weekly', grade: '8A' });
      setFile(null);
      load();
    } catch (e: any) {
      toast({ title: 'Upload failed', description: e.message || 'Unknown error', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (item: Tables<'timetables'>) => {
    await deleteMedia(item.image_url);
    await supabase.from('timetables').delete().eq('id', item.id);
    load();
  };

  return (
    <div>
      <div className="bg-card rounded-2xl p-4 mb-4 space-y-3">
        <h3 className="font-semibold text-sm">Upload Timetable</h3>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Title (e.g. Term 1 Week 4)" className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm" />
        <div className="grid grid-cols-2 gap-2">
          <select value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} className="px-3 py-2 rounded-lg bg-background border border-border text-sm">
            {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
          </select>
          <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as any })} className="px-3 py-2 rounded-lg bg-background border border-border text-sm">
            <option value="weekly">Weekly</option>
            <option value="exam">Exam</option>
          </select>
        </div>
        <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] || null)} className="text-sm" />
        <button onClick={save} disabled={saving} className="px-4 py-2 rounded-lg gold-gradient text-sm font-bold text-primary flex items-center gap-1 disabled:opacity-50"><Plus className="w-3 h-3" />{saving ? 'Uploading…' : 'Upload'}</button>
      </div>
      <div className="space-y-2">
        {items.map((i) => (
          <div key={i.id} className="bg-card rounded-xl p-3 flex items-center gap-3">
            <img src={i.image_url} className="w-16 h-12 rounded-lg object-cover" />
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-sm truncate">{i.title}</h4>
              <p className="text-xs text-muted-foreground capitalize">
                {(i as any).grade ? `${(i as any).grade} · ` : ''}{i.type}
              </p>
            </div>
            <button onClick={() => remove(i)} className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-3 h-3" /></button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminTimetables;
