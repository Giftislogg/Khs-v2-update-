import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { uploadMedia, deleteMedia } from '@/lib/supabase-helpers';
import { Plus, Trash2, Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const AdminPdfs = () => {
  const [items, setItems] = useState<any[]>([]);
  const [form, setForm] = useState({ title: '', description: '', category: 'general', pdf_url: '', recommended: false });
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [thumbFile, setThumbFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = () =>
    supabase
      .from('pdfs' as any)
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => data && setItems(data as any[]));

  useEffect(() => {
    load();
  }, []);

  const save = async () => {
    if (!form.title.trim()) {
      toast({ title: 'Missing info', description: 'Title is required.', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      let pdfUrl = form.pdf_url.trim();
      if (pdfFile) pdfUrl = await uploadMedia(pdfFile, 'pdfs');
      if (!pdfUrl) {
        toast({ title: 'No PDF', description: 'Provide a PDF file or URL.', variant: 'destructive' });
        return;
      }
      let thumbnailUrl: string | null = null;
      if (thumbFile) thumbnailUrl = await uploadMedia(thumbFile, 'thumbnails');
      const { error } = await supabase.from('pdfs' as any).insert({
        title: form.title,
        description: form.description,
        category: form.category,
        pdf_url: pdfUrl,
        thumbnail_url: thumbnailUrl,
        recommended: form.recommended,
      });
      if (error) throw error;
      toast({ title: 'Added', description: 'PDF saved.' });
      setForm({ title: '', description: '', category: 'general', pdf_url: '', recommended: false });
      setPdfFile(null);
      setThumbFile(null);
      load();
    } catch (e: any) {
      toast({ title: 'Could not save', description: e.message || 'Unknown error', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (item: any) => {
    if (item.pdf_url?.includes('/media/')) await deleteMedia(item.pdf_url);
    if (item.thumbnail_url) await deleteMedia(item.thumbnail_url);
    await supabase.from('pdfs' as any).delete().eq('id', item.id);
    load();
  };

  const toggleRecommended = async (item: any) => {
    await supabase.from('pdfs' as any).update({ recommended: !item.recommended }).eq('id', item.id);
    load();
  };

  return (
    <div>
      <div className="bg-card rounded-2xl p-4 mb-4 space-y-3">
        <h3 className="font-semibold text-sm">Add PDF</h3>
        <input
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          placeholder="Title"
          className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm"
        />
        <textarea
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="Description"
          rows={2}
          className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm"
        />
        <input
          value={form.category}
          onChange={(e) => setForm({ ...form, category: e.target.value })}
          placeholder="Category (e.g. Math, Science)"
          className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm"
        />
        <div>
          <label className="text-xs text-muted-foreground">Upload PDF file</label>
          <input
            type="file"
            accept="application/pdf"
            onChange={(e) => setPdfFile(e.target.files?.[0] || null)}
            className="text-sm block"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">…or paste PDF URL</label>
          <input
            value={form.pdf_url}
            onChange={(e) => setForm({ ...form, pdf_url: e.target.value })}
            placeholder="https://..."
            className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Thumbnail (optional)</label>
          <input
            type="file"
            accept="image/*"
            onChange={(e) => setThumbFile(e.target.files?.[0] || null)}
            className="text-sm block"
          />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={form.recommended}
            onChange={(e) => setForm({ ...form, recommended: e.target.checked })}
          />
          Mark as recommended
        </label>
        <button
          onClick={save}
          disabled={saving}
          className="px-4 py-2 rounded-lg gold-gradient text-sm font-bold text-primary flex items-center gap-1 disabled:opacity-50"
        >
          <Plus className="w-3 h-3" />
          {saving ? 'Saving…' : 'Add'}
        </button>
      </div>

      <div className="space-y-2">
        {items.map((i) => (
          <div key={i.id} className="bg-card rounded-xl p-3 flex items-center gap-3">
            {i.thumbnail_url && <img src={i.thumbnail_url} className="w-12 h-12 rounded-lg object-cover" />}
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-sm truncate">{i.title}</h4>
              <p className="text-xs text-muted-foreground">{i.category}</p>
            </div>
            <button
              onClick={() => toggleRecommended(i)}
              className={`p-1.5 rounded-lg ${i.recommended ? 'text-gold' : 'text-muted-foreground hover:text-foreground'}`}
              title="Toggle recommended"
            >
              <Star className={`w-4 h-4 ${i.recommended ? 'fill-current' : ''}`} />
            </button>
            <button onClick={() => remove(i)} className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive">
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminPdfs;
