import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { uploadMedia, deleteMedia } from '@/lib/supabase-helpers';
import { Plus, Trash2 } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';

type VideoMode = 'file' | 'url';

const AdminVideos = () => {
  const [items, setItems] = useState<Tables<'videos'>[]>([]);
  const [mode, setMode] = useState<VideoMode>('file');
  const [form, setForm] = useState({ title: '', description: '', video_url: '' });
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [thumbFile, setThumbFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = () =>
    supabase
      .from('videos')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => data && setItems(data));
  useEffect(() => {
    load();
  }, []);

  const save = async () => {
    if (!form.title.trim()) {
      toast({ title: 'Missing info', description: 'Title is required.', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      let videoUrl = '';
      if (mode === 'file') {
        if (!videoFile) {
          toast({ title: 'No file', description: 'Choose a video file.', variant: 'destructive' });
          return;
        }
        videoUrl = await uploadMedia(videoFile, 'videos');
      } else {
        if (!form.video_url.trim()) {
          toast({ title: 'No URL', description: 'Paste a YouTube/Vimeo URL.', variant: 'destructive' });
          return;
        }
        videoUrl = form.video_url.trim();
      }
      let thumbnailUrl: string | null = null;
      if (thumbFile) thumbnailUrl = await uploadMedia(thumbFile, 'thumbnails');
      const { error } = await supabase.from('videos').insert({
        title: form.title,
        description: form.description,
        video_url: videoUrl,
        thumbnail_url: thumbnailUrl,
        video_type: mode,
      } as any);
      if (error) throw error;
      toast({ title: 'Added', description: 'Video published.' });
      setForm({ title: '', description: '', video_url: '' });
      setVideoFile(null);
      setThumbFile(null);
      load();
    } catch (e: any) {
      toast({ title: 'Could not save', description: e.message || 'Unknown error', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (item: Tables<'videos'>) => {
    if ((item as any).video_type !== 'url' && item.video_url.includes('/media/')) {
      await deleteMedia(item.video_url);
    }
    if (item.thumbnail_url) await deleteMedia(item.thumbnail_url);
    await supabase.from('videos').delete().eq('id', item.id);
    load();
  };

  return (
    <div>
      <div className="bg-card rounded-2xl p-4 mb-4 space-y-3">
        <h3 className="font-semibold text-sm">Add Video</h3>

        <div className="flex gap-2">
          {(['file', 'url'] as VideoMode[]).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                mode === m ? 'gold-gradient text-primary' : 'bg-background text-muted-foreground'
              }`}
            >
              {m === 'file' ? 'Upload File' : 'YouTube / Vimeo URL'}
            </button>
          ))}
        </div>

        <input
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          placeholder="Title"
          className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm"
        />
        <textarea
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="Description"
          rows={2}
          className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm"
        />

        {mode === 'file' ? (
          <div>
            <label className="text-xs text-muted-foreground">Video file (mp4)</label>
            <input
              type="file"
              accept="video/*"
              onChange={(e) => setVideoFile(e.target.files?.[0] || null)}
              className="text-sm block"
            />
          </div>
        ) : (
          <div>
            <label className="text-xs text-muted-foreground">YouTube or Vimeo link</label>
            <input
              value={form.video_url}
              onChange={(e) => setForm({ ...form, video_url: e.target.value })}
              placeholder="https://youtube.com/watch?v=..."
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm"
            />
          </div>
        )}

        <div>
          <label className="text-xs text-muted-foreground">Thumbnail (optional)</label>
          <input
            type="file"
            accept="image/*"
            onChange={(e) => setThumbFile(e.target.files?.[0] || null)}
            className="text-sm block"
          />
        </div>
        <button
          onClick={save}
          disabled={saving}
          className="px-4 py-2 rounded-lg gold-gradient text-sm font-bold text-primary flex items-center gap-1 disabled:opacity-50"
        >
          <Plus className="w-3 h-3" />
          {saving ? 'Saving…' : 'Add Video'}
        </button>
      </div>

      <div className="space-y-2">
        {items.map((i) => (
          <div key={i.id} className="bg-card rounded-xl p-3 flex items-center gap-3">
            {i.thumbnail_url ? (
              <img src={i.thumbnail_url} className="w-16 h-12 rounded-lg object-cover" />
            ) : (
              <div className="w-16 h-12 rounded-lg gold-gradient" />
            )}
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-sm truncate">{i.title}</h4>
              <p className="text-[10px] uppercase text-muted-foreground">
                {(i as any).video_type === 'url' ? 'Embed' : 'File'}
              </p>
            </div>
            <button onClick={() => remove(i)} className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive">
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminVideos;
