import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Save } from 'lucide-react';

const AdminAppVersion = () => {
  const [form, setForm] = useState({ latest_version: '', update_message: '', download_url: '' });
  const [id, setId] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    supabase.from('app_version').select('*').limit(1).single().then(({ data }) => {
      if (data) {
        setId(data.id);
        setForm({ latest_version: data.latest_version, update_message: data.update_message || '', download_url: data.download_url || '' });
      }
    });
  }, []);

  const save = async () => {
    if (id) {
      await supabase.from('app_version').update(form).eq('id', id);
    } else {
      const { data } = await supabase.from('app_version').insert(form).select().single();
      if (data) setId(data.id);
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="bg-card rounded-2xl p-4 space-y-3 max-w-md">
      <h3 className="font-semibold text-sm">App Version Control</h3>
      <div>
        <label className="text-xs text-muted-foreground">Latest Version</label>
        <input value={form.latest_version} onChange={(e) => setForm({ ...form, latest_version: e.target.value })} placeholder="e.g. 0.3" className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm" />
      </div>
      <div>
        <label className="text-xs text-muted-foreground">Update Message</label>
        <textarea value={form.update_message} onChange={(e) => setForm({ ...form, update_message: e.target.value })} placeholder="What's new..." rows={2} className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm" />
      </div>
      <div>
        <label className="text-xs text-muted-foreground">APK Download URL</label>
        <input value={form.download_url} onChange={(e) => setForm({ ...form, download_url: e.target.value })} placeholder="https://..." className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm" />
      </div>
      <button onClick={save} className="px-4 py-2 rounded-lg gold-gradient text-sm font-bold text-primary flex items-center gap-1">
        <Save className="w-3 h-3" />{saved ? 'Saved!' : 'Save'}
      </button>
    </div>
  );
};

export default AdminAppVersion;
