import * as React from "react";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface ImageCarouselProps {
  images: string[];
  className?: string;
  aspectRatio?: "square" | "video" | "wide";
  /** Show the full image without cropping (default true). */
  contain?: boolean;
}

export const ImageCarousel = ({
  images,
  className,
  aspectRatio = "video",
  contain = true,
}: ImageCarouselProps) => {
  const [emblaRef, emblaApi] = useEmblaCarousel(
    { loop: true, align: "center", duration: 28 },
    [Autoplay({ delay: 5000, stopOnInteraction: true, stopOnMouseEnter: true })]
  );
  const [selectedIndex, setSelectedIndex] = React.useState(0);
  const [lightboxIndex, setLightboxIndex] = React.useState<number | null>(null);

  const onSelect = React.useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  React.useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on("select", onSelect);
    emblaApi.on("reInit", onSelect);
  }, [emblaApi, onSelect]);

  const aspectClasses = {
    square: "aspect-square",
    video: "aspect-video",
    wide: "aspect-[21/9]",
  };

  const fit = contain ? "object-contain" : "object-cover";
  const bg = contain ? "bg-black" : "";

  if (images.length === 0) return null;

  const renderSingle = (
    <div
      className={cn(
        "overflow-hidden rounded-xl cursor-zoom-in",
        aspectClasses[aspectRatio],
        bg,
        className
      )}
      onClick={() => setLightboxIndex(0)}
    >
      <img src={images[0]} alt="" className={cn("h-full w-full", fit)} loading="lazy" />
    </div>
  );

  return (
    <>
      {images.length === 1 ? (
        renderSingle
      ) : (
        <div className={cn("relative group", className)}>
          <div
            className={cn("overflow-hidden rounded-xl", aspectClasses[aspectRatio], bg)}
            ref={emblaRef}
          >
            <div className="flex">
              {images.map((src, index) => (
                <div className="flex-[0_0_100%] min-w-0" key={index}>
                  <button
                    type="button"
                    onClick={() => setLightboxIndex(index)}
                    className={cn("h-full w-full block cursor-zoom-in", aspectClasses[aspectRatio], bg)}
                  >
                    <img
                      src={src}
                      alt=""
                      className={cn("h-full w-full", fit)}
                      loading="lazy"
                      draggable={false}
                    />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5 px-2.5 py-1.5 rounded-full bg-black/40 backdrop-blur-md">
            {images.map((_, index) => (
              <div
                key={index}
                className={cn(
                  "h-1.5 rounded-full transition-all duration-300",
                  index === selectedIndex ? "bg-white w-4" : "bg-white/50 w-1.5"
                )}
              />
            ))}
          </div>

          <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-black/40 backdrop-blur-md text-white text-[10px] font-bold">
            {selectedIndex + 1}/{images.length}
          </div>
        </div>
      )}

      {lightboxIndex !== null && (
        <Lightbox
          images={images}
          startIndex={lightboxIndex}
          onClose={() => setLightboxIndex(null)}
        />
      )}
    </>
  );
};

const Lightbox = ({
  images,
  startIndex,
  onClose,
}: {
  images: string[];
  startIndex: number;
  onClose: () => void;
}) => {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    loop: images.length > 1,
    startIndex,
    duration: 25,
  });
  const [idx, setIdx] = React.useState(startIndex);

  React.useEffect(() => {
    if (!emblaApi) return;
    const sync = () => setIdx(emblaApi.selectedScrollSnap());
    emblaApi.on("select", sync);
    sync();
  }, [emblaApi]);

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") emblaApi?.scrollNext();
      if (e.key === "ArrowLeft") emblaApi?.scrollPrev();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [emblaApi, onClose]);

  return (
    <div
      className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center animate-fade-in"
      onClick={onClose}
    >
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white"
        aria-label="Close"
      >
        <X className="w-5 h-5" />
      </button>

      {images.length > 1 && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10 px-3 py-1 rounded-full bg-white/10 text-white text-xs font-semibold">
          {idx + 1} / {images.length}
        </div>
      )}

      <div className="overflow-hidden w-full h-full" ref={emblaRef} onClick={(e) => e.stopPropagation()}>
        <div className="flex h-full">
          {images.map((src, i) => (
            <div key={i} className="flex-[0_0_100%] min-w-0 h-full flex items-center justify-center p-4">
              <img
                src={src}
                alt=""
                className="max-h-full max-w-full object-contain select-none"
                draggable={false}
              />
            </div>
          ))}
        </div>
      </div>

      {images.length > 1 && (
        <>
          <button
            onClick={(e) => {
              e.stopPropagation();
              emblaApi?.scrollPrev();
            }}
            className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white"
            aria-label="Previous"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              emblaApi?.scrollNext();
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white"
            aria-label="Next"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </>
      )}
    </div>
  );
};
