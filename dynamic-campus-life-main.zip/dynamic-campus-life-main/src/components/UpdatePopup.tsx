import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { APP_VERSION } from '@/lib/supabase-helpers';

const UpdatePopup = () => {
  const [update, setUpdate] = useState<{ message: string; url: string } | null>(null);

  useEffect(() => {
    supabase.from('app_version').select('*').limit(1).single().then(({ data }) => {
      if (data && data.latest_version !== APP_VERSION && data.download_url) {
        setUpdate({ message: data.update_message || 'New version available!', url: data.download_url });
      }
    });
  }, []);

  if (!update) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-foreground/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-surface-elevated rounded-2xl p-6 mx-6 max-w-sm w-full card-shadow-lg">
        <h3 className="text-lg font-bold mb-2">Update Available</h3>
        <p className="text-muted-foreground text-sm mb-4">{update.message}</p>
        <div className="flex gap-3">
          <button onClick={() => setUpdate(null)} className="flex-1 py-2 rounded-lg border border-border text-sm font-medium">
            Later
          </button>
          <a href={update.url} className="flex-1 py-2 rounded-lg gold-gradient text-center text-sm font-bold text-primary">
            Download
          </a>
        </div>
      </div>
    </div>
  );
};

export default UpdatePopup;
