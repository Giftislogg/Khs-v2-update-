import { useEffect } from 'react';
import { Network } from '@capacitor/network';
import { toast } from 'sonner';
import { WifiOff } from 'lucide-react';
import React from 'react';

export const useNetworkStatus = () => {
  useEffect(() => {
    let handler: any;

    const setupNetworkListener = async () => {
      const status = await Network.getStatus();
      if (!status.connected) {
        showOfflineToast();
      }

      handler = await Network.addListener('networkStatusChange', (status) => {
        if (!status.connected) {
          showOfflineToast();
        } else {
          toast.success('You are back online', {
            id: 'network-status',
            duration: 2000,
          });
        }
      });
    };

    const showOfflineToast = () => {
      toast.error('No internet connection', {
        id: 'network-status',
        duration: Infinity,
        icon: React.createElement(WifiOff, { className: "w-4 h-4" }),
        description: 'Please check your internet settings.',
      });
    };

    setupNetworkListener();

    return () => {
      if (handler) {
        handler.remove();
      }
    };
  }, []);
};
