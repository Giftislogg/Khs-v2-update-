import { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';
import VideoPlayer from '@/components/VideoPlayer';
import { Search, FileText, Sparkles, Download, Video, BookOpen } from 'lucide-react';

type Tab = 'pdfs' | 'videos';

const Studies = () => {
  const [tab, setTab] = useState<Tab>('pdfs');
  const [pdfs, setPdfs] = useState<any[]>([]);
  const [videos, setVideos] = useState<Tables<'videos'>[]>([]);
  const [pdfsLoaded, setPdfsLoaded] = useState(false);
  const [videosLoaded, setVideosLoaded] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    supabase
      .from('pdfs' as any)
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        setPdfs((data as any[]) || []);
        setPdfsLoaded(true);
      });
    supabase
      .from('videos')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        setVideos(data || []);
        setVideosLoaded(true);
      });
  }, []);

  const q = search.trim().toLowerCase();
  const filteredPdfs = useMemo(() => {
    if (!q) return pdfs;
    return pdfs.filter(
      (p) =>
        p.title?.toLowerCase().includes(q) ||
        p.description?.toLowerCase().includes(q) ||
        p.category?.toLowerCase().includes(q)
    );
  }, [pdfs, q]);
  const filteredVideos = useMemo(() => {
    if (!q) return videos;
    return videos.filter(
      (v) =>
        v.title?.toLowerCase().includes(q) ||
        v.description?.toLowerCase().includes(q)
    );
  }, [videos, q]);
  const recommended = pdfs.filter((p) => p.recommended);

  return (
    <div className="pb-24 min-h-screen bg-gradient-to-b from-[#fef9ee] via-white to-[#f3f6ff]">
      {/* Vibrant Header */}
      <div className="px-5 pt-8 pb-5 animate-fade-in relative">
        <div className="absolute -top-4 right-0 w-40 h-40 rounded-full bg-gold/20 blur-3xl pointer-events-none" />
        <div className="absolute top-20 left-0 w-32 h-32 rounded-full bg-primary/10 blur-3xl pointer-events-none" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-9 h-9 rounded-2xl gold-gradient flex items-center justify-center shadow-md">
              <BookOpen className="w-4.5 h-4.5 text-primary" strokeWidth={2.5} />
            </div>
            <h1 className="text-2xl font-extrabold text-primary">Study Hub</h1>
          </div>
          <p className="text-muted-foreground text-sm ml-11">PDFs, study videos, all in one place ✨</p>
        </div>
      </div>

      {/* Search */}
      <div className="px-5 mb-4">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tab === 'pdfs' ? 'Search PDFs, notes, summaries…' : 'Search study videos…'}
            className="w-full pl-10 pr-4 py-3.5 bg-white rounded-2xl text-sm card-shadow-lg border-0 focus:outline-none focus:ring-2 focus:ring-gold transition-all"
          />
        </div>
      </div>

      {/* Top tab switch */}
      <div className="px-5 mb-5">
        <div className="bg-white rounded-2xl p-1 flex card-shadow">
          {([
            { id: 'pdfs', label: 'PDFs', icon: FileText },
            { id: 'videos', label: 'Videos', icon: Video },
          ] as const).map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as Tab)}
              className={`flex-1 min-h-[44px] py-2.5 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-1.5 ${
                tab === t.id ? 'gold-gradient text-primary shadow-md' : 'text-muted-foreground'
              }`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* PDFs */}
      {tab === 'pdfs' && (
        <div className="animate-fade-in">
          {/* Recommended */}
          {!q && recommended.length > 0 && (
            <div className="mb-5">
              <div className="px-5 flex items-center gap-1.5 mb-2">
                <Sparkles className="w-3.5 h-3.5 text-gold" />
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Recommended</p>
              </div>
              <div className="flex gap-3 overflow-x-auto scrollbar-hide px-5 pb-2">
                {recommended.map((p) => (
                  <a
                    key={p.id}
                    href={p.pdf_url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-shrink-0 w-40 bg-white rounded-2xl overflow-hidden card-shadow-lg active:scale-95 transition-transform"
                  >
                    {p.thumbnail_url ? (
                      <img src={p.thumbnail_url} alt={p.title} className="w-full h-24 object-cover" />
                    ) : (
                      <div className="w-full h-24 gold-gradient flex items-center justify-center">
                        <FileText className="w-8 h-8 text-primary" />
                      </div>
                    )}
                    <div className="p-2.5">
                      <p className="text-[10px] text-gold font-semibold uppercase">{p.category}</p>
                      <h4 className="text-xs font-semibold line-clamp-2 leading-tight mt-0.5">{p.title}</h4>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}

          <div className="px-5">
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-3">
              {q ? `Results (${filteredPdfs.length})` : 'All Materials'}
            </p>
            {!pdfsLoaded && (
              <div className="space-y-2.5">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="bg-white rounded-2xl p-3 card-shadow flex items-center gap-3 animate-pulse">
                    <div className="w-12 h-12 rounded-xl bg-muted flex-shrink-0" />
                    <div className="flex-1 space-y-2">
                      <div className="h-2 w-1/4 bg-muted rounded" />
                      <div className="h-3 w-3/4 bg-muted rounded" />
                    </div>
                  </div>
                ))}
              </div>
            )}
            {pdfsLoaded && filteredPdfs.length === 0 && (
              <div className="bg-white rounded-2xl p-8 text-center card-shadow">
                <FileText className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-muted-foreground text-sm">
                  {q ? 'No matches found' : 'No PDFs uploaded yet — check back soon'}
                </p>
              </div>
            )}
            <div className="space-y-2.5">
              {filteredPdfs.map((p, i) => (
                <a
                  key={p.id}
                  href={p.pdf_url}
                  target="_blank"
                  rel="noreferrer"
                  style={{ animationDelay: `${i * 40}ms` }}
                  className="bg-white rounded-2xl p-3 card-shadow flex items-center gap-3 active:scale-[0.98] transition-transform animate-fade-in"
                >
                  <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-5 h-5 text-gold" />
                  </div>
                  <div className="flex-1 min-w-0">
                    {p.category && (
                      <p className="text-[10px] uppercase tracking-wider text-gold font-bold">{p.category}</p>
                    )}
                    <h4 className="font-semibold text-sm truncate">{p.title}</h4>
                    {p.description && (
                      <p className="text-xs text-muted-foreground line-clamp-1">{p.description}</p>
                    )}
                  </div>
                  <Download className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                </a>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Videos */}
      {tab === 'videos' && (
        <div className="px-5 animate-fade-in">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-3">
            {q ? `Results (${filteredVideos.length})` : 'Study Videos'}
          </p>
          {!videosLoaded && (
            <div className="grid grid-cols-2 gap-3">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-2xl overflow-hidden card-shadow animate-pulse">
                  <div className="aspect-video bg-muted" />
                  <div className="p-2 space-y-1.5">
                    <div className="h-2 w-3/4 bg-muted rounded" />
                  </div>
                </div>
              ))}
            </div>
          )}
          {videosLoaded && filteredVideos.length === 0 && (
            <div className="bg-white rounded-2xl p-8 text-center card-shadow">
              <Video className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground text-sm">
                {q ? 'No matches found' : 'No videos yet — fresh study clips coming soon 🎬'}
              </p>
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            {filteredVideos.map((v, i) => (
              <div
                key={v.id}
                style={{ animationDelay: `${i * 50}ms` }}
                className="bg-white rounded-2xl overflow-hidden card-shadow animate-fade-in"
              >
                <VideoPlayer
                  url={v.video_url}
                  type={(v as any).video_type === 'url' ? 'url' : 'file'}
                  thumbnail={v.thumbnail_url}
                  title={v.title}
                />
                <div className="p-2.5">
                  <h4 className="font-semibold text-xs line-clamp-2 leading-tight">{v.title}</h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Studies;
