import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Calendar, MapPin, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { Tables } from '@/integrations/supabase/types';
import { ImageCarousel } from '@/components/ImageCarousel';

const Events = () => {
  const [events, setEvents] = useState<Tables<'events'>[]>([]);
  const [loaded, setLoaded] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    supabase
      .from('events')
      .select('*')
      .order('event_date', { ascending: true })
      .then(({ data }) => {
        setEvents(data || []);
        setLoaded(true);
      });
  }, []);

  return (
    <div className="pb-20 min-h-screen">
      <div className="px-5 pt-6 pb-4 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-2 rounded-xl bg-card"><ArrowLeft className="w-4 h-4" /></button>
        <h1 className="text-xl font-bold">Events</h1>
      </div>
      <div className="px-5 space-y-3">
        {!loaded && (
          <div className="space-y-3">
            {[0, 1].map((i) => (
              <div key={i} className="bg-card rounded-2xl overflow-hidden card-shadow animate-pulse">
                <div className="aspect-[21/9] bg-muted" />
                <div className="p-4 space-y-2">
                  <div className="h-3 w-1/2 bg-muted rounded" />
                  <div className="h-2 w-3/4 bg-muted rounded" />
                </div>
              </div>
            ))}
          </div>
        )}
        {loaded && events.length === 0 && (
          <div className="bg-card rounded-2xl p-8 text-center card-shadow my-6">
            <Calendar className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm font-semibold">No events scheduled</p>
            <p className="text-muted-foreground text-xs mt-1">Check back soon for school rallies, sports days and trips! 🎉</p>
          </div>
        )}
        {events.map((e) => (
          <div key={e.id} className="bg-card rounded-2xl overflow-hidden card-shadow animate-fade-in">
            {e.image_urls && e.image_urls.length > 0 ? (
              <ImageCarousel images={e.image_urls} className="rounded-none" aspectRatio="wide" />
            ) : e.image_url && (
              <ImageCarousel images={[e.image_url]} className="rounded-none" aspectRatio="wide" />
            )}
            <div className="p-4">
              <h3 className="font-semibold">{e.title}</h3>
              {e.description && <p className="text-muted-foreground text-sm mt-1">{e.description}</p>}
              <div className="flex items-center gap-3 mt-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1 text-gold"><Calendar className="w-3 h-3" />{new Date(e.event_date).toLocaleDateString()}</span>
                {e.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{e.location}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Events;
