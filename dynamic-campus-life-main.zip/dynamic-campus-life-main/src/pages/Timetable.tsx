import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, Calendar, GraduationCap, Sparkles } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';

const GRADES = ['8A', '8B', '8C', '8D', '9A', '9B', '9C', '9D'] as const;
type Grade = (typeof GRADES)[number];
type TtType = 'weekly' | 'exam';

const STORAGE_KEY = 'dl_grade';

const Timetable = () => {
  const navigate = useNavigate();
  const stored = (typeof window !== 'undefined' && (localStorage.getItem(STORAGE_KEY) as Grade)) || null;
  const [grade, setGrade] = useState<Grade | null>(stored);
  const [pickerOpen, setPickerOpen] = useState<boolean>(!stored);
  const [ttType, setTtType] = useState<TtType>('weekly');
  const [items, setItems] = useState<Tables<'timetables'>[]>([]);

  useEffect(() => {
    supabase
      .from('timetables')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => data && setItems(data));
  }, []);

  const choose = (g: Grade) => {
    setGrade(g);
    localStorage.setItem(STORAGE_KEY, g);
    setPickerOpen(false);
  };

  // Filter: match grade exactly OR show ungraded fallbacks (so older uploads still appear).
  const filtered = items.filter((t) => {
    if (t.type !== ttType) return false;
    const g = (t as any).grade as string | null | undefined;
    if (!g) return true; // legacy timetable with no grade
    return g === grade;
  });

  return (
    <div className="pb-24 min-h-screen bg-gradient-to-b from-[#f8f9fa] via-white to-[#fef9ee]">
      {/* Header */}
      <div className="px-5 pt-8 pb-4 animate-fade-in">
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={() => navigate(-1)}
            className="p-2.5 rounded-xl bg-card card-shadow active:scale-95 transition-transform"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-primary">Timetable</h1>
            <p className="text-xs text-muted-foreground">Your class schedule, anytime</p>
          </div>
          <button
            onClick={() => setPickerOpen(true)}
            className="px-3 py-2 rounded-xl gold-gradient text-primary text-xs font-bold flex items-center gap-1.5 active:scale-95 transition-transform shadow-md"
          >
            <GraduationCap className="w-3.5 h-3.5" />
            {grade || 'Pick class'}
          </button>
        </div>

        {/* Vibrant banner */}
        <div className="relative overflow-hidden rounded-3xl p-5 navy-gradient text-white card-shadow-lg">
          <div className="absolute -right-6 -top-6 w-28 h-28 rounded-full bg-gold/30 blur-2xl" />
          <div className="absolute -left-4 -bottom-6 w-24 h-24 rounded-full bg-white/10 blur-xl" />
          <div className="relative">
            <Sparkles className="w-5 h-5 text-gold mb-2" />
            <p className="text-[11px] uppercase tracking-widest text-gold font-bold">Class</p>
            <p className="text-3xl font-black leading-none mt-1">{grade || '—'}</p>
            <p className="text-xs text-white/70 mt-2">
              {grade ? 'Tap "Pick class" to switch' : 'Choose your class to see your schedule'}
            </p>
          </div>
        </div>
      </div>

      {/* Type tabs */}
      <div className="px-5 mb-4 flex gap-2">
        {(['weekly', 'exam'] as TtType[]).map((t) => (
          <button
            key={t}
            onClick={() => setTtType(t)}
            className={`min-h-[44px] flex-1 px-5 py-2.5 rounded-2xl text-sm font-bold transition-all ${
              ttType === t
                ? 'gold-gradient text-primary shadow-md'
                : 'bg-card text-muted-foreground'
            }`}
          >
            {t === 'weekly' ? 'Weekly Schedule' : 'Exam Schedule'}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="px-5 space-y-4 animate-fade-in">
        {!grade && (
          <div className="bg-card rounded-2xl p-8 text-center card-shadow">
            <GraduationCap className="w-10 h-10 text-gold mx-auto mb-3" />
            <p className="font-bold text-sm">Pick your class first</p>
            <p className="text-muted-foreground text-xs mt-1">
              We'll show the timetable for your grade only.
            </p>
            <button
              onClick={() => setPickerOpen(true)}
              className="mt-4 px-5 py-2.5 rounded-xl gold-gradient text-primary text-sm font-bold"
            >
              Choose class
            </button>
          </div>
        )}

        {grade && filtered.length === 0 && (
          <div className="bg-card rounded-2xl p-8 text-center card-shadow">
            <Calendar className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-muted-foreground text-sm">
              No {ttType} timetable for {grade} yet
            </p>
            <p className="text-[11px] text-muted-foreground mt-1">Check back soon</p>
          </div>
        )}

        {grade &&
          filtered.map((t) => (
            <div key={t.id} className="bg-card rounded-3xl overflow-hidden card-shadow-lg">
              <div className="px-4 py-3 border-b border-border flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase tracking-widest text-gold font-bold">
                    {t.type === 'weekly' ? 'Weekly' : 'Exam'} · {(t as any).grade || 'All grades'}
                  </p>
                  <h3 className="font-semibold text-sm">{t.title}</h3>
                </div>
              </div>
              <a href={t.image_url} target="_blank" rel="noreferrer" className="block">
                <img src={t.image_url} alt={t.title} className="w-full" />
              </a>
            </div>
          ))}
      </div>

      {/* Grade picker dialog */}
      <Dialog open={pickerOpen} onOpenChange={setPickerOpen}>
        <DialogContent className="max-w-sm rounded-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-gold" />
              Which class are you in?
            </DialogTitle>
            <DialogDescription>Pick your class to see the right timetable.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-4 gap-2 py-2">
            {GRADES.map((g) => (
              <button
                key={g}
                onClick={() => choose(g)}
                className={`min-h-[56px] rounded-2xl font-extrabold text-sm transition-all active:scale-95 ${
                  grade === g
                    ? 'gold-gradient text-primary shadow-md'
                    : 'bg-card hover:bg-muted text-foreground'
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Timetable;
