import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Calendar, Clock, Sparkles, BookOpen, TrendingUp, Bell } from 'lucide-react';
import { getAllTerms, getTermStatus } from '@/lib/saTerms';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';

const motivationalQuotes = [
  'Let your light shine — Khanyisa.',
  'Discipline is the bridge between goals and accomplishment.',
  'Small steps every day lead to big results.',
  'You are capable of more than you imagine.',
  'Excellence is a habit, not an act.',
];

const TermInsights = () => {
  const navigate = useNavigate();
  const status = getTermStatus();
  const terms = getAllTerms();
  const [events, setEvents] = useState<Tables<'events'>[]>([]);
  const [announcements, setAnnouncements] = useState<Tables<'announcements'>[]>([]);
  const quote = motivationalQuotes[new Date().getDate() % motivationalQuotes.length];

  useEffect(() => {
    supabase
      .from('events')
      .select('*')
      .gte('event_date', new Date().toISOString())
      .order('event_date', { ascending: true })
      .limit(5)
      .then(({ data }) => data && setEvents(data));
    supabase
      .from('announcements')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(3)
      .then(({ data }) => data && setAnnouncements(data));
  }, []);

  return (
    <div className="min-h-screen pb-28 bg-background">
      {/* Header */}
      <div className="px-5 pt-10 pb-4 flex items-center gap-3">
        <button
          onClick={() => navigate(-1)}
          className="p-2.5 rounded-2xl bg-card card-shadow active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5 text-primary" />
        </button>
        <div>
          <h1 className="text-xl font-extrabold text-primary leading-tight">Term Insights</h1>
          <p className="text-[11px] text-muted-foreground font-medium">
            South African School Calendar
          </p>
        </div>
      </div>

      {/* Big progress card */}
      <div className="mx-5 mb-5 rounded-3xl p-6 navy-gradient relative overflow-hidden card-shadow-lg">
        <div className="absolute -top-10 -right-10 w-44 h-44 rounded-full bg-gold/25 blur-3xl" />
        <p className="text-[10px] uppercase tracking-widest text-gold-light font-bold mb-2">
          Currently
        </p>
        <h2 className="text-3xl font-black text-white mb-1">
          {status.mode === 'in_term'
            ? `Term ${status.term?.term}`
            : status.mode === 'holiday'
            ? 'Holiday Break'
            : 'School Closed'}
        </h2>
        <p className="text-white/70 text-sm mb-5">{status.message}</p>

        {status.mode === 'in_term' && (
          <>
            <div className="relative h-4 rounded-full bg-white/10 overflow-hidden mb-3">
              <div
                className="h-full gold-gradient rounded-full transition-all duration-1000"
                style={{ width: `${status.percent}%` }}
              />
            </div>
            <div className="grid grid-cols-3 gap-2 mt-4">
              <Stat label="Progress" value={`${status.percent}%`} />
              <Stat label="Days Left" value={status.daysRemaining.toString()} />
              <Stat label="Weeks Left" value={status.weeksRemaining.toString()} />
            </div>
          </>
        )}
      </div>

      {/* Motivational */}
      <div className="mx-5 mb-5 rounded-2xl p-4 bg-card border border-gold/30 card-shadow flex gap-3 items-start">
        <Sparkles className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
        <p className="text-sm text-foreground font-medium italic">"{quote}"</p>
      </div>

      {/* Full calendar */}
      <Section icon={Calendar} title="Academic Calendar">
        <div className="space-y-2">
          {terms.map((t) => {
            const isCurrent = status.term?.term === t.term;
            return (
              <div
                key={t.term}
                className={`rounded-2xl p-3.5 flex items-center justify-between ${
                  isCurrent
                    ? 'bg-primary text-primary-foreground card-shadow'
                    : 'bg-card border border-border'
                }`}
              >
                <div>
                  <p className={`text-[10px] uppercase tracking-widest font-bold ${
                    isCurrent ? 'text-gold-light' : 'text-muted-foreground'
                  }`}>
                    Term {t.term}
                  </p>
                  <p className="font-bold text-sm mt-0.5">
                    {new Date(t.start).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' })} —{' '}
                    {new Date(t.end).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' })}
                  </p>
                </div>
                {isCurrent && (
                  <span className="text-[10px] font-extrabold uppercase tracking-widest bg-gold text-primary px-2 py-1 rounded-full">
                    Now
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </Section>

      {/* Upcoming events */}
      {events.length > 0 && (
        <Section icon={Clock} title="Upcoming Events">
          <div className="space-y-2">
            {events.map((e) => {
              const days = Math.ceil(
                (new Date(e.event_date).getTime() - Date.now()) / 86400000
              );
              return (
                <div key={e.id} className="bg-card rounded-2xl p-3 flex items-center gap-3 border border-border">
                  <div className="w-11 h-11 rounded-xl gold-gradient flex flex-col items-center justify-center flex-shrink-0">
                    <span className="text-[9px] font-bold text-primary/80 uppercase">
                      {new Date(e.event_date).toLocaleDateString('en', { month: 'short' })}
                    </span>
                    <span className="text-base font-black text-primary leading-none">
                      {new Date(e.event_date).getDate()}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm text-foreground truncate">{e.title}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {days <= 0 ? 'Today' : `In ${days} day${days === 1 ? '' : 's'}`}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {/* Announcements */}
      {announcements.length > 0 && (
        <Section icon={Bell} title="Latest Announcements">
          <div className="space-y-2">
            {announcements.map((a) => (
              <div key={a.id} className="bg-card rounded-2xl p-3 border border-border">
                <p className="font-bold text-sm text-foreground">{a.title}</p>
                <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{a.content}</p>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Placeholder analytics */}
      <Section icon={TrendingUp} title="Coming Soon">
        <div className="grid grid-cols-2 gap-2">
          {[
            { icon: BookOpen, label: 'Attendance %' },
            { icon: TrendingUp, label: 'Performance' },
            { icon: Clock, label: 'Homework' },
            { icon: Sparkles, label: 'Daily Study' },
          ].map((c) => (
            <div
              key={c.label}
              className="rounded-2xl bg-card border border-border p-4 flex flex-col gap-2 opacity-70"
            >
              <c.icon className="w-5 h-5 text-gold" />
              <p className="text-xs font-bold text-foreground">{c.label}</p>
              <p className="text-[10px] text-muted-foreground">Available in next phase</p>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
};

const Stat = ({ label, value }: { label: string; value: string }) => (
  <div className="bg-white/10 rounded-xl p-3 text-center backdrop-blur">
    <p className="text-xl font-black text-white">{value}</p>
    <p className="text-[9px] uppercase tracking-widest text-white/60 font-bold mt-0.5">{label}</p>
  </div>
);

const Section = ({
  icon: Icon,
  title,
  children,
}: {
  icon: typeof Calendar;
  title: string;
  children: React.ReactNode;
}) => (
  <div className="px-5 mb-6">
    <div className="flex items-center gap-2 mb-3">
      <Icon className="w-4 h-4 text-gold" />
      <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
        {title}
      </h3>
    </div>
    {children}
  </div>
);

export default TermInsights;
