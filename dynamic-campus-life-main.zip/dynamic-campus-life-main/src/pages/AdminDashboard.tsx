import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { LogOut, Megaphone, Calendar, Newspaper, Clock, Video, Settings, FileText } from 'lucide-react';
import AdminAnnouncements from '@/components/admin/AdminAnnouncements';
import AdminEvents from '@/components/admin/AdminEvents';
import AdminPosts from '@/components/admin/AdminPosts';
import AdminTimetables from '@/components/admin/AdminTimetables';
import AdminVideos from '@/components/admin/AdminVideos';
import AdminPdfs from '@/components/admin/AdminPdfs';
import AdminAppVersion from '@/components/admin/AdminAppVersion';

const tabs = [
  { id: 'announcements', label: 'Announcements', icon: Megaphone },
  { id: 'events', label: 'Events', icon: Calendar },
  { id: 'posts', label: 'Posts', icon: Newspaper },
  { id: 'timetables', label: 'Timetable', icon: Clock },
  { id: 'pdfs', label: 'PDFs', icon: FileText },
  { id: 'videos', label: 'Videos', icon: Video },
  { id: 'version', label: 'App Version', icon: Settings },
];

const AdminDashboard = () => {
  const { signOut, isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('announcements');

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!isAdmin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 px-5">
        <p className="text-muted-foreground">You don't have admin access.</p>
        <button onClick={() => navigate('/')} className="px-4 py-2 rounded-xl gold-gradient text-sm font-bold text-primary">
          Go Home
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border px-5 py-4 flex items-center justify-between">
        <div>
          <h1 className="font-bold text-lg">Admin Panel</h1>
          <p className="text-xs text-muted-foreground">Downtown Lobby</p>
        </div>
        <button onClick={signOut} className="p-2 rounded-xl bg-card hover:bg-muted transition-colors">
          <LogOut className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-border overflow-x-auto">
        <div className="flex px-5 gap-1 min-w-max">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab.id ? 'border-gold text-gold' : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        {activeTab === 'announcements' && <AdminAnnouncements />}
        {activeTab === 'events' && <AdminEvents />}
        {activeTab === 'posts' && <AdminPosts />}
        {activeTab === 'timetables' && <AdminTimetables />}
        {activeTab === 'pdfs' && <AdminPdfs />}
        {activeTab === 'videos' && <AdminVideos />}
        {activeTab === 'version' && <AdminAppVersion />}
      </div>
    </div>
  );
};

export default AdminDashboard;
