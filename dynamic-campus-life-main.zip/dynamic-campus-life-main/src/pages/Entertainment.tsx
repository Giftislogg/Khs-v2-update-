import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';
import VideoPlayer from '@/components/VideoPlayer';
import { Sparkles } from 'lucide-react';

const Entertainment = () => {
  const [videos, setVideos] = useState<Tables<'videos'>[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from('videos')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        if (data) setVideos(data);
        setLoading(false);
      });
  }, []);

  const featured = videos[0];
  const rest = videos.slice(1);

  return (
    <div className="pb-24 min-h-screen">
      {/* Header */}
      <div className="px-5 pt-8 pb-5 animate-fade-in">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl gold-gradient flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-primary" />
          </div>
          <h1 className="text-xl font-bold">Entertainment</h1>
        </div>
        <p className="text-muted-foreground text-sm mt-1">Watch & enjoy without leaving the app</p>
      </div>

      {loading && <p className="text-center text-muted-foreground text-sm py-12">Loading…</p>}

      {!loading && videos.length === 0 && (
        <div className="px-5 py-12">
          <div className="bg-card rounded-3xl p-8 text-center card-shadow-lg">
            <div className="w-14 h-14 rounded-2xl gold-gradient flex items-center justify-center mx-auto mb-3">
              <Sparkles className="w-7 h-7 text-primary" />
            </div>
            <p className="text-sm font-semibold">No videos uploaded yet</p>
            <p className="text-muted-foreground text-xs mt-1">Fresh school clips, highlights and fun videos drop here weekly. Stay tuned! 🎬</p>
          </div>
        </div>
      )}

      {/* Featured */}
      {featured && (
        <div className="px-5 mb-6 animate-fade-in">
          <p className="text-xs font-bold text-gold uppercase tracking-widest mb-2">Featured</p>
          <div className="bg-card rounded-3xl overflow-hidden card-shadow-lg">
            <VideoPlayer
              url={featured.video_url}
              type={(featured as any).video_type === 'url' ? 'url' : 'file'}
              thumbnail={featured.thumbnail_url}
              title={featured.title}
            />
            <div className="p-4">
              <h3 className="font-bold">{featured.title}</h3>
              {featured.description && (
                <p className="text-muted-foreground text-xs mt-1 line-clamp-2">{featured.description}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Grid of more videos */}
      {rest.length > 0 && (
        <div className="px-5 animate-slide-up">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-3">More to watch</p>
          <div className="grid grid-cols-2 gap-3">
            {rest.map((v) => (
              <div key={v.id} className="bg-card rounded-2xl overflow-hidden card-shadow">
                <VideoPlayer
                  url={v.video_url}
                  type={(v as any).video_type === 'url' ? 'url' : 'file'}
                  thumbnail={v.thumbnail_url}
                  title={v.title}
                />
                <div className="p-2.5">
                  <h4 className="font-semibold text-xs line-clamp-2 leading-tight">{v.title}</h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Entertainment;
