import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, Heart, MessageCircle, Send, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { Tables } from '@/integrations/supabase/types';
import { getClientId } from '@/lib/supabase-helpers';
import { ImageCarousel } from '@/components/ImageCarousel';

type Post = Tables<'posts'>;

const Posts = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [likes, setLikes] = useState<Record<string, number>>({});
  const [myLikes, setMyLikes] = useState<Record<string, string>>({}); // postId -> like row id
  const [commentCounts, setCommentCounts] = useState<Record<string, number>>({});
  const [openComments, setOpenComments] = useState<Post | null>(null);
  const navigate = useNavigate();
  const clientId = getClientId();

  const loadAll = async () => {
    const { data: postsData } = await supabase
      .from('posts')
      .select('*')
      .order('created_at', { ascending: false });
    setPosts(postsData || []);
    setLoaded(true);
    if (!postsData || postsData.length === 0) return;

    const ids = postsData.map((p) => p.id);

    const [{ data: likeRows }, { data: commentRows }] = await Promise.all([
      supabase.from('post_likes' as any).select('id,post_id,client_id').in('post_id', ids),
      supabase.from('post_comments' as any).select('post_id').in('post_id', ids),
    ]);

    const likeCount: Record<string, number> = {};
    const mine: Record<string, string> = {};
    (likeRows as any[] || []).forEach((r) => {
      likeCount[r.post_id] = (likeCount[r.post_id] || 0) + 1;
      if (r.client_id === clientId) mine[r.post_id] = r.id;
    });
    const cc: Record<string, number> = {};
    (commentRows as any[] || []).forEach((r) => {
      cc[r.post_id] = (cc[r.post_id] || 0) + 1;
    });
    setLikes(likeCount);
    setMyLikes(mine);
    setCommentCounts(cc);
  };

  useEffect(() => {
    loadAll();
  }, []);

  const toggleLike = async (postId: string) => {
    if (myLikes[postId]) {
      const id = myLikes[postId];
      setMyLikes((m) => {
        const n = { ...m };
        delete n[postId];
        return n;
      });
      setLikes((l) => ({ ...l, [postId]: Math.max(0, (l[postId] || 1) - 1) }));
      await supabase.from('post_likes' as any).delete().eq('id', id);
    } else {
      setLikes((l) => ({ ...l, [postId]: (l[postId] || 0) + 1 }));
      const { data } = await supabase
        .from('post_likes' as any)
        .insert({ post_id: postId, client_id: clientId })
        .select('id')
        .single();
      if (data) setMyLikes((m) => ({ ...m, [postId]: (data as any).id }));
    }
  };

  return (
    <div className="pb-24 min-h-screen">
      <div className="px-5 pt-6 pb-4 flex items-center gap-3 animate-fade-in">
        <button onClick={() => navigate(-1)} className="p-2.5 rounded-xl bg-card card-shadow active:scale-95 transition-transform">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-xl font-bold">News & Posts</h1>
          <p className="text-xs text-muted-foreground">Updates from school</p>
        </div>
      </div>

      <div className="px-5 space-y-4">
        {!loaded && (
          <div className="space-y-4">
            {[0, 1].map((i) => (
              <div key={i} className="bg-card rounded-3xl overflow-hidden card-shadow-lg animate-pulse">
                <div className="px-4 pt-4 pb-3 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3 w-1/3 bg-muted rounded" />
                    <div className="h-2 w-1/4 bg-muted rounded" />
                  </div>
                </div>
                <div className="px-4 pb-3 space-y-2">
                  <div className="h-3 w-3/4 bg-muted rounded" />
                  <div className="h-2 w-full bg-muted rounded" />
                </div>
                <div className="aspect-video bg-muted" />
              </div>
            ))}
          </div>
        )}
        {loaded && posts.length === 0 && (
          <p className="text-muted-foreground text-sm text-center py-12">No posts yet</p>
        )}
        {posts.map((p, i) => (
          <article
            key={p.id}
            style={{ animationDelay: `${i * 60}ms` }}
            className="bg-card rounded-3xl overflow-hidden card-shadow-lg animate-fade-in"
          >
            {/* Header */}
            <div className="px-4 pt-4 pb-3 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full gold-gradient flex items-center justify-center text-primary font-bold text-sm">
                DL
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">Downtown Lobby</p>
                <p className="text-[11px] text-muted-foreground">
                  {new Date(p.created_at).toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })}
                </p>
              </div>
              {p.category && (
                <span className="text-[10px] uppercase tracking-wider font-bold text-gold bg-gold/10 px-2 py-1 rounded-full">
                  {p.category}
                </span>
              )}
            </div>

            {/* Content */}
            <div className="px-4 pb-3">
              <h3 className="font-bold text-base">{p.title}</h3>
              <p className="text-sm text-foreground/80 mt-1 whitespace-pre-wrap">{p.content}</p>
            </div>
            {p.image_urls && p.image_urls.length > 0 ? (
              <ImageCarousel images={p.image_urls} className="rounded-none" />
            ) : p.image_url && (
              <ImageCarousel images={[p.image_url]} className="rounded-none" />
            )}

            {/* Actions */}
            <div className="px-4 py-3 flex items-center gap-5 border-t border-border">
              <button
                onClick={() => toggleLike(p.id)}
                className="flex items-center gap-1.5 text-sm font-medium active:scale-95 transition-transform"
              >
                <Heart
                  className={`w-5 h-5 transition-colors ${
                    myLikes[p.id] ? 'fill-red-500 text-red-500' : 'text-muted-foreground'
                  }`}
                />
                <span className={myLikes[p.id] ? 'text-red-500' : 'text-muted-foreground'}>
                  {likes[p.id] || 0}
                </span>
              </button>
              <button
                onClick={() => setOpenComments(p)}
                className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground active:scale-95 transition-transform"
              >
                <MessageCircle className="w-5 h-5" />
                <span>{commentCounts[p.id] || 0}</span>
              </button>
            </div>
          </article>
        ))}
      </div>

      {openComments && (
        <CommentsSheet
          post={openComments}
          onClose={() => {
            setOpenComments(null);
            loadAll();
          }}
          clientId={clientId}
        />
      )}
    </div>
  );
};

const CommentsSheet = ({
  post,
  onClose,
  clientId,
}: {
  post: Post;
  onClose: () => void;
  clientId: string;
}) => {
  const [comments, setComments] = useState<any[]>([]);
  const [name, setName] = useState(localStorage.getItem('dl_name') || '');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);

  const load = () => {
    supabase
      .from('post_comments' as any)
      .select('*')
      .eq('post_id', post.id)
      .order('created_at', { ascending: true })
      .then(({ data }) => data && setComments(data as any[]));
  };

  useEffect(() => {
    load();
  }, [post.id]);

  const submit = async () => {
    const trimmedName = name.trim().slice(0, 40) || 'Student';
    const trimmedText = text.trim().slice(0, 500);
    if (!trimmedText) return;
    setSending(true);
    localStorage.setItem('dl_name', trimmedName);
    await supabase.from('post_comments' as any).insert({
      post_id: post.id,
      author_name: trimmedName,
      content: trimmedText,
      client_id: clientId,
    });
    setText('');
    setSending(false);
    load();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end animate-fade-in" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full bg-background rounded-t-3xl max-h-[85vh] flex flex-col animate-slide-up pb-[env(safe-area-inset-bottom)]"
      >
        <div className="px-5 py-4 border-b border-border flex items-center justify-between">
          <div>
            <h3 className="font-bold">Comments</h3>
            <p className="text-xs text-muted-foreground line-clamp-1">{post.title}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-muted">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
          {comments.length === 0 && (
            <p className="text-center text-sm text-muted-foreground py-8">Be the first to comment</p>
          )}
          {comments.map((c) => (
            <div key={c.id} className="flex gap-2.5">
              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-xs font-bold flex-shrink-0">
                {c.author_name?.[0]?.toUpperCase() || 'S'}
              </div>
              <div className="flex-1 bg-card rounded-2xl px-3 py-2">
                <p className="text-xs font-semibold">{c.author_name}</p>
                <p className="text-sm">{c.content}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  {new Date(c.created_at).toLocaleString()}
                </p>
              </div>
            </div>
          ))}
        </div>
        <div className="border-t border-border p-3 space-y-2 bg-card">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your name"
            maxLength={40}
            className="w-full px-3 py-2 rounded-xl bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-gold"
          />
          <div className="flex gap-2">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submit()}
              placeholder="Write a comment..."
              maxLength={500}
              className="flex-1 px-3 py-2 rounded-xl bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-gold"
            />
            <button
              onClick={submit}
              disabled={sending || !text.trim()}
              className="px-4 rounded-xl gold-gradient text-primary font-bold disabled:opacity-50 active:scale-95 transition-transform"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Posts;
