import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

const AdminLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError('');
    setLoading(true);
    // Hard timeout so the button never feels "stuck"
    const timeout = setTimeout(() => {
      setError('Still trying… check your internet connection.');
    }, 5000);
    try {
      await signIn(email.trim(), password);
      clearTimeout(timeout);
      navigate('/admin', { replace: true });
    } catch (err: any) {
      clearTimeout(timeout);
      const msg = err?.message || '';
      if (/invalid login/i.test(msg)) setError('Wrong email or password.');
      else if (/network|fetch/i.test(msg)) setError('Network error. Try again.');
      else setError(msg || 'Login failed');
    } finally {
      clearTimeout(timeout);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-5 bg-background">
      <div className="w-full max-w-sm">
        <h1 className="text-2xl font-bold text-center mb-1">Admin Panel</h1>
        <p className="text-muted-foreground text-sm text-center mb-6">Downtown Lobby</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-card border border-border text-sm focus:outline-none focus:ring-2 focus:ring-gold"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-card border border-border text-sm focus:outline-none focus:ring-2 focus:ring-gold"
            required
          />
          {error && <p className="text-destructive text-sm">{error}</p>}
          <p className="text-[11px] text-muted-foreground text-center">
            Use the same email & password you signed up with. New here? Create an account first via the sign-up flow.
          </p>
          <button type="submit" disabled={loading} className="w-full py-3 rounded-xl gold-gradient font-bold text-sm text-primary disabled:opacity-50">
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
