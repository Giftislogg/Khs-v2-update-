import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Calendar, Newspaper, Clock, ChevronRight, Bell, Sparkles } from 'lucide-react';
import type { Tables } from '@/integrations/supabase/types';
import HeroCarousel from '@/components/HeroCarousel';
import TermProgress from '@/components/TermProgress';
import SideDrawer, { DrawerTrigger } from '@/components/SideDrawer';

const Index = () => {
  const navigate = useNavigate();
  const [events, setEvents] = useState<Tables<'events'>[]>([]);
  const [unread, setUnread] = useState(0);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    supabase
      .from('events')
      .select('*')
      .order('event_date', { ascending: true })
      .limit(3)
      .then(({ data }) => data && setEvents(data));

    // Simple unread badge: count announcements created since last seen
    const lastSeen = localStorage.getItem('dl_last_seen_announcements');
    supabase
      .from('announcements')
      .select('id, created_at')
      .order('created_at', { ascending: false })
      .limit(20)
      .then(({ data }) => {
        if (!data) return;
        if (!lastSeen) {
          setUnread(data.length);
        } else {
          setUnread(data.filter((a) => new Date(a.created_at) > new Date(lastSeen)).length);
        }
      });
  }, []);

  const openBell = () => {
    localStorage.setItem('dl_last_seen_announcements', new Date().toISOString());
    setUnread(0);
    navigate('/posts');
  };

  // News & Posts in the middle (per user request). Timetable now has its own page.
  const cards = [
    { icon: Calendar, label: 'Events', path: '/events' },
    { icon: Newspaper, label: 'News & Posts', path: '/posts' },
    { icon: Clock, label: 'Timetable', path: '/timetable' },
  ];

  return (
    <div className="pb-24 min-h-screen bg-gradient-to-b from-background via-background to-surface relative overflow-hidden">
      <SideDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} />
      {/* Vibe blobs */}
      <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-gold/15 blur-3xl pointer-events-none" />
      <div className="absolute top-40 -left-20 w-64 h-64 rounded-full bg-primary/10 blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="px-5 pt-10 pb-6 animate-fade-in flex items-start justify-between relative gap-3">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <DrawerTrigger onClick={() => setDrawerOpen(true)} />
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <img src="/logo.png" alt="Downtown Lobby logo" className="w-9 h-9 rounded-full shadow-sm object-cover" />
              <div className="min-w-0">
                <h1 className="text-base font-bold text-primary leading-tight truncate">Downtown Lobby</h1>
                <p className="text-[9px] font-medium text-gold-dark uppercase tracking-widest">Let Your Light Shine</p>
              </div>
            </div>
            <h2 className="text-2xl font-extrabold mt-5 text-primary flex items-center gap-2">
              Hello Student!
              <span className="inline-block">👋</span>
            </h2>
            <p className="text-muted-foreground text-sm mt-1 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-gold" />
              Welcome back to Khanyisa High
            </p>
          </div>
        </div>

        {/* Notification bell */}
        <button
          onClick={openBell}
          aria-label="Notifications"
          className="relative mt-2 p-3 rounded-2xl bg-card card-shadow active:scale-95 transition-transform"
        >
          <Bell className="w-5 h-5 text-primary" strokeWidth={2.2} />
          {unread > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full gold-gradient text-[10px] font-extrabold text-primary flex items-center justify-center shadow-md ring-2 ring-card">
              {unread > 9 ? '9+' : unread}
            </span>
          )}
        </button>
      </div>

      {/* SA School Term Progress */}
      <TermProgress />

      {/* Auto-sliding hero carousel */}
      <HeroCarousel />

      {/* Quick Access */}
      <div className="px-5 mb-8 relative">
        <h2 className="text-xs font-bold text-primary/60 mb-3 uppercase tracking-[0.2em] ml-1">Quick Access</h2>
        <div className="grid grid-cols-3 gap-3">
          {cards.map((card, i) => (
            <button
              key={card.path}
              onClick={() => navigate(card.path)}
              style={{ animationDelay: `${i * 80}ms` }}
              className="bg-card rounded-2xl p-3 shadow-[0_6px_16px_-6px_rgba(0,0,0,0.08)] flex flex-col items-center gap-2 transition-all active:scale-95 hover:shadow-md animate-fade-in min-h-[88px] justify-center border border-border"
            >
              <div
                className={`w-10 h-10 rounded-xl ${i === 1 ? 'gold-gradient' : 'navy-gradient'} flex items-center justify-center shadow-md shadow-black/5`}
              >
                <card.icon className={`w-5 h-5 ${i === 1 ? 'text-primary' : 'text-white'}`} strokeWidth={2.2} />
              </div>
              <span className="text-[10.5px] font-bold text-center leading-tight text-foreground/80">{card.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Upcoming Events */}
      {events.length > 0 && (
        <div className="px-5 animate-slide-up relative">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Upcoming Events</h2>
            <button
              onClick={() => navigate('/events')}
              className="text-xs font-semibold text-gold flex items-center gap-0.5"
            >
              View all <ChevronRight className="w-3 h-3" />
            </button>
          </div>
          <div className="space-y-3">
            {events.map((event) => (
              <button
                key={event.id}
                onClick={() => navigate('/events')}
                className="w-full text-left bg-white rounded-2xl p-4 card-shadow flex gap-3 active:scale-[0.98] transition-transform"
              >
                <div className="w-12 h-12 rounded-2xl gold-gradient flex flex-col items-center justify-center flex-shrink-0 shadow-md">
                  <span className="text-[10px] font-bold text-primary/80 uppercase tracking-tighter">
                    {new Date(event.event_date).toLocaleDateString(undefined, { month: 'short' })}
                  </span>
                  <span className="text-lg font-black text-primary leading-none">
                    {new Date(event.event_date).getDate()}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm truncate">{event.title}</h3>
                  {event.description && (
                    <p className="text-muted-foreground text-xs mt-0.5 line-clamp-1">{event.description}</p>
                  )}
                  {event.location && <p className="text-[11px] text-gold mt-1">📍 {event.location}</p>}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Index;
