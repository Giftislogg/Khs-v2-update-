import { useEffect } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, useNavigate, useLocation } from "react-router-dom";
import { App as CapApp } from '@capacitor/app';
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import BottomNav from "@/components/BottomNav";
import UpdatePopup from "@/components/UpdatePopup";
import { initNotifications } from "@/lib/notifications";
import LoadingScreen from "@/components/LoadingScreen";
import { ThemeProvider } from "@/lib/theme";
import Index from "./pages/Index";
import Events from "./pages/Events";
import Posts from "./pages/Posts";
import Studies from "./pages/Studies";
import Timetable from "./pages/Timetable";
import Entertainment from "./pages/Entertainment";
import TermInsights from "./pages/TermInsights";
import AdminLogin from "./pages/AdminLogin";
import AdminDashboard from "./pages/AdminDashboard";
import NotFound from "./pages/NotFound";
import { useAuth } from "@/hooks/useAuth";
import { useNetworkStatus } from "@/hooks/useNetworkStatus";

const queryClient = new QueryClient();

const AppContent = () => {
  const { isAdmin, loading, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  useNetworkStatus();

  useEffect(() => {
    initNotifications();

    const backHandler = CapApp.addListener('backButton', ({ canGoBack }) => {
      if (location.pathname === '/') {
        CapApp.exitApp();
      } else if (canGoBack) {
        window.history.back();
      } else {
        navigate('/');
      }
    });

    return () => {
      backHandler.then(h => h.remove());
    };
  }, [location, navigate]);

  const isUserApp = import.meta.env.VITE_APP_ROLE !== 'admin';

  if (!isUserApp) {
    if (loading) return <LoadingScreen />;
    if (!user || !isAdmin) {
      return (
        <Routes>
          <Route path="*" element={<AdminLogin />} />
        </Routes>
      );
    }
    return (
      <Routes>
        <Route path="/" element={<AdminDashboard />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="*" element={<AdminDashboard />} />
      </Routes>
    );
  }

  return (
    <>
      <UpdatePopup />
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/events" element={<Events />} />
        <Route path="/posts" element={<Posts />} />
        <Route path="/studies" element={<Studies />} />
        <Route path="/timetable" element={<Timetable />} />
        <Route path="/entertainment" element={<Entertainment />} />
        <Route path="/term-insights" element={<TermInsights />} />
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <BottomNav />
    </>
  );
};

const App = () => {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AuthProvider>
            <BrowserRouter>
              <LoadingScreen />
              <Toaster />
              <Sonner />
              <AppContent />
            </BrowserRouter>
          </AuthProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
};

export default App;
